# SmartWardrobe AI

Digital wardrobe + AI outfit recommendations. Answers **"What should I wear today?"** using only clothes the user owns.

```
Flutter app ──(Firebase ID token)──▶ Django REST API ──▶ PostgreSQL (SQLite in dev)
     │                                   │  ├─ services/recommender.py  scoring engine
     └─ images ▶ Firebase Storage        │  ├─ services/ai/             colour, pattern, CLIP classifier, rembg
        (URL stored in DB, not bytes)    │  ├─ services/weather.py      OpenWeather (mock fallback)
                                         │  └─ services/ai/chat.py      LLM (optional) / rule-based stylist
```

## Quick start (demo mode, no Firebase needed)

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env              # DJANGO_DEBUG=1, DEV_AUTH=1
python manage.py migrate
python manage.py seed_demo demo   # 10 sample clothes
python manage.py runserver
python manage.py test tests       # 18 tests

cd ../mobile
flutter create . --org com.smartwardrobe --project-name smartwardrobe_ai   # generates android/ ios/ web/
flutter pub get
flutter run --dart-define=API_URL=http://10.0.2.2:8000/api     # Android emulator
```
Tap **Continue in demo mode**, open **Today**, pick *College / Hot / Casual* and press **Suggest outfits**.

Required platform settings after `flutter create`:
- **Android** `AndroidManifest.xml`: `INTERNET`, `CAMERA`, `ACCESS_COARSE_LOCATION`; add `android:usesCleartextTraffic="true"` for local HTTP only (remove for release).
- **iOS** `Info.plist`: `NSCameraUsageDescription`, `NSPhotoLibraryUsageDescription`, `NSLocationWhenInUseUsageDescription`.

## Production setup

1. **Firebase**: create a project, enable Email/Password + Google sign-in, enable Storage, deploy `storage.rules`.
   Run `flutterfire configure`, add `google-services.json` / `GoogleService-Info.plist`.
2. **Backend env**: `DJANGO_DEBUG=0`, strong `DJANGO_SECRET_KEY`, `DATABASE_URL=postgres://...`, `FIREBASE_CREDENTIALS=/path/service-account.json`,
   `DJANGO_ALLOWED_HOSTS`, `CORS_ALLOWED_ORIGINS`, optional `OPENWEATHER_API_KEY`, `ANTHROPIC_API_KEY`. `DEV_AUTH` is ignored when DEBUG is off.
3. `docker compose up --build` (API + Postgres). Put it behind HTTPS (the app enforces SSL redirect when DEBUG=0).
4. Build the app: `flutter run --dart-define=USE_FIREBASE=true --dart-define=API_URL=https://api.example.com/api`.
5. Optional AI extras: `pip install rembg transformers torch` enables background removal and CLIP clothing classification.

## API (all require `Authorization: Bearer <Firebase ID token>`)

| Method | Path | Purpose |
|---|---|---|
| GET/PATCH/DELETE | `/api/me/` | profile, style prefs, delete account + all data |
| GET/POST | `/api/wardrobe/items/` | list (filter `?category=`), add (file or Firebase `image_url`) with auto-analysis |
| PATCH/DELETE | `/api/wardrobe/items/{id}/` | correct AI guesses, favourite, remove |
| POST | `/api/wardrobe/items/{id}/reanalyze/` | re-run AI (`remove_background`) |
| POST | `/api/recommend/` | `{occasion, weather?, style?, lat?, lon?, count?}` -> scored outfits with explanations |
| GET/POST | `/api/outfits/`, `/{id}/feedback/`, `/{id}/wear/` | saved looks, like/dislike, log worn |
| GET | `/api/analytics/` | totals, colours, most worn, unused 60d, gaps |
| GET | `/api/weather/` | normalised weather snapshot |
| POST | `/api/chat/` | stylist chat grounded in the user's wardrobe |

## How recommendations work
Filter by occasion formality and weather warmth, build top+bottom+footwear(+layer in cold/rain) combos from owned items,
then score: colour harmony 26%, formality fit 22%, weather fit 20%, freshness 10%, feedback learning 10%, style 8%, favourites 4%.
Rejected combinations are never re-suggested; liked/disliked pieces shift future scores. Every outfit ships an explanation and score breakdown.

## Security notes
Firebase tokens verified server-side; every query is scoped to the authenticated user (tested); image URLs restricted to Firebase Storage hosts;
SSRF guard on server-side fetches; upload size limits; per-user rate limits (stricter on AI endpoints); Storage rules isolate user folders;
account deletion cascades; no secrets in the repo (`.env` is git-ignored).

## Roadmap
Virtual try-on (diffusion/VTON API), calendar-aware suggestions, shopping-gap suggestions, outfit sharing, offline cache, push reminders.

## Known limits
- Without `transformers`/`torch`, clothing type is not auto-detected; the app flags the item "Check details" and the user confirms.
- Colour/pattern detection is heuristic and works best on a plain background.
- Flutter code was written without a Flutter SDK in the build environment; run `flutter analyze` and `flutter test` first and fix any version drift.
