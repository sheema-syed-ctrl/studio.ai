import 'package:flutter_test/flutter_test.dart';
import 'package:smartwardrobe_ai/models/models.dart';

void main() {
  test('Recommendation parses API payload', () {
    final item = {'id': 1, 'display_name': 'White T-Shirt', 'category': 'top', 'primary_color': 'white', 'image_src': ''};
    final rec = Recommendation.fromJson({
      'weather': {'temp_c': 34, 'band': 'hot', 'rain': false, 'source': 'manual'},
      'outfits': [
        {'id': 9, 'occasion': 'college', 'explanation': 'ok', 'score': 0.8, 'items': [item]}
      ],
      'missing': [],
      'message': '',
    });
    expect(rec.weather.band, 'hot');
    expect(rec.outfits.single.items.single.name, 'White T-Shirt');
    expect(rec.outfits.single.liked, isNull);
  });

  test('ClothingItem flags unknown category for review', () {
    final i = ClothingItem.fromJson({'id': 2, 'category': 'unknown'});
    expect(i.needsReview, isTrue);
  });
}
