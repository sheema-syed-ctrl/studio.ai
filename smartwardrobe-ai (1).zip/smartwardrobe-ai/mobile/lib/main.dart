import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/auth.dart';
import 'core/config.dart';
import 'core/theme.dart';
import 'features/auth/login_screen.dart';
import 'features/home/shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (AppConfig.useFirebase) {
    // Requires google-services.json / GoogleService-Info.plist (see README), or
    // `flutterfire configure` + DefaultFirebaseOptions for web.
    await Firebase.initializeApp();
  }
  runApp(const ProviderScope(child: SmartWardrobeApp()));
}

class SmartWardrobeApp extends ConsumerWidget {
  const SmartWardrobeApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final signedIn = ref.watch(authProvider.select((s) => s.status == AuthStatus.signedIn));
    return MaterialApp(
      title: 'SmartWardrobe AI',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: signedIn ? const HomeShell() : const LoginScreen(),
    );
  }
}
