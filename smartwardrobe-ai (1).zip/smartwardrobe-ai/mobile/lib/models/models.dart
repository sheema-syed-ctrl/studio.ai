class ClothingItem {
  final int id;
  final String name, category, subcategory, primaryColor, pattern, imageSrc;
  final List<String> secondaryColors, seasons, occasions;
  final int formality, warmth, timesWorn;
  final bool isFavorite;
  final Map<String, dynamic> aiMeta;

  ClothingItem.fromJson(Map<String, dynamic> j)
      : id = j['id'] as int,
        name = (j['display_name'] ?? j['name'] ?? '') as String,
        category = (j['category'] ?? 'unknown') as String,
        subcategory = (j['subcategory'] ?? '') as String,
        primaryColor = (j['primary_color'] ?? '') as String,
        pattern = (j['pattern'] ?? '') as String,
        imageSrc = (j['image_src'] ?? '') as String,
        secondaryColors = List<String>.from(j['secondary_colors'] ?? const []),
        seasons = List<String>.from(j['seasons'] ?? const []),
        occasions = List<String>.from(j['occasions'] ?? const []),
        formality = (j['formality'] ?? 3) as int,
        warmth = (j['warmth'] ?? 2) as int,
        timesWorn = (j['times_worn'] ?? 0) as int,
        isFavorite = (j['is_favorite'] ?? false) as bool,
        aiMeta = Map<String, dynamic>.from(j['ai_meta'] ?? const {});

  bool get needsReview => category == 'unknown' || (aiMeta['source'] == 'heuristic');
}

class Weather {
  final double tempC;
  final String band, source;
  final bool rain;
  Weather.fromJson(Map<String, dynamic> j)
      : tempC = (j['temp_c'] as num).toDouble(),
        band = j['band'] as String,
        rain = (j['rain'] ?? false) as bool,
        source = (j['source'] ?? '') as String;
}

class Outfit {
  final int id;
  final String occasion, explanation;
  final double score;
  final List<ClothingItem> items;
  final bool isSaved;
  final bool? liked;
  final DateTime? createdAt;

  Outfit.fromJson(Map<String, dynamic> j)
      : id = j['id'] as int,
        occasion = (j['occasion'] ?? '') as String,
        explanation = (j['explanation'] ?? '') as String,
        score = ((j['score'] ?? 0) as num).toDouble(),
        isSaved = (j['is_saved'] ?? false) as bool,
        liked = j['feedback'] == null ? null : j['feedback']['liked'] as bool,
        createdAt = DateTime.tryParse((j['created_at'] ?? '') as String),
        items = (j['items'] as List).map((e) => ClothingItem.fromJson(e as Map<String, dynamic>)).toList();
}

class Recommendation {
  final Weather weather;
  final List<Outfit> outfits;
  final List<String> missing;
  final String message;
  Recommendation.fromJson(Map<String, dynamic> j)
      : weather = Weather.fromJson(j['weather'] as Map<String, dynamic>),
        outfits = (j['outfits'] as List).map((e) => Outfit.fromJson(e as Map<String, dynamic>)).toList(),
        missing = List<String>.from(j['missing'] ?? const []),
        message = (j['message'] ?? '') as String;
}

class Analytics {
  final int total, unusedCount, outfitsWorn;
  final double? likeRate;
  final Map<String, int> byCategory;
  final List<MapEntry<String, int>> topColors;
  final List<ClothingItem> mostWorn, unused;
  final List<String> gaps;

  Analytics.fromJson(Map<String, dynamic> j)
      : total = j['total_items'] as int,
        unusedCount = j['unused_count'] as int,
        outfitsWorn = j['outfits_worn'] as int,
        likeRate = (j['like_rate'] as num?)?.toDouble(),
        byCategory = (j['by_category'] as Map).map((k, v) => MapEntry(k as String, v as int)),
        topColors = (j['top_colors'] as List).map((e) => MapEntry(e[0] as String, e[1] as int)).toList(),
        mostWorn = (j['most_worn'] as List).map((e) => ClothingItem.fromJson(e as Map<String, dynamic>)).toList(),
        unused = (j['unused_60d'] as List).map((e) => ClothingItem.fromJson(e as Map<String, dynamic>)).toList(),
        gaps = List<String>.from(j['gaps'] ?? const []);
}

class ChatMsg {
  final String role, text;
  const ChatMsg(this.role, this.text);
}
