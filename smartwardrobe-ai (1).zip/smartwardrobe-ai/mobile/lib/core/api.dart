import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import 'auth.dart';
import 'config.dart';

class ApiException implements Exception {
  final String message;
  final int? status;
  ApiException(this.message, [this.status]);
  @override
  String toString() => message;
}

class Api {
  final Dio _dio;
  final Ref _ref;

  Api(this._ref)
      : _dio = Dio(BaseOptions(
          baseUrl: AppConfig.apiUrl,
          connectTimeout: const Duration(seconds: 10),
          receiveTimeout: const Duration(seconds: 40),
        )) {
    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (o, h) async {
        final header = await _ref.read(authProvider.notifier).authHeader();
        if (header != null) o.headers['Authorization'] = header;
        h.next(o);
      },
      onError: (e, h) {
        if (e.response?.statusCode == 401) _ref.read(authProvider.notifier).signOut();
        h.next(e);
      },
    ));
  }

  Future<T> _guard<T>(Future<T> Function() call) async {
    try {
      return await call();
    } on DioException catch (e) {
      final code = e.response?.statusCode;
      if (e.type == DioExceptionType.connectionError || e.type == DioExceptionType.connectionTimeout) {
        throw ApiException('Cannot reach the server. Check your connection.');
      }
      if (code == 429) throw ApiException('Too many requests. Try again in a few minutes.', code);
      final data = e.response?.data;
      final detail = data is Map && data.isNotEmpty ? (data['detail'] ?? data.values.first).toString() : 'Request failed';
      throw ApiException(detail.replaceAll(RegExp(r'[\[\]]'), ''), code);
    }
  }

  List<dynamic> _results(dynamic d) => d is Map ? d['results'] as List : d as List;

  Future<List<ClothingItem>> items({String? category}) => _guard(() async {
        final r = await _dio.get('/wardrobe/items/', queryParameters: {if (category != null) 'category': category});
        return _results(r.data).map((e) => ClothingItem.fromJson(e)).toList();
      });

  /// Dev/demo: send the file to Django. Production: pass [imageUrl] from Firebase Storage.
  Future<ClothingItem> addItem({File? file, String? imageUrl, Map<String, dynamic> fields = const {}}) => _guard(() async {
        final body = FormData.fromMap({
          ...fields,
          if (imageUrl != null) 'image_url': imageUrl,
          if (file != null) 'image': await MultipartFile.fromFile(file.path, filename: 'item.jpg'),
        });
        final r = await _dio.post('/wardrobe/items/', data: body);
        return ClothingItem.fromJson(r.data);
      });

  Future<ClothingItem> updateItem(int id, Map<String, dynamic> patch) =>
      _guard(() async => ClothingItem.fromJson((await _dio.patch('/wardrobe/items/$id/', data: patch)).data));

  Future<void> deleteItem(int id) => _guard(() => _dio.delete('/wardrobe/items/$id/'));

  Future<Recommendation> recommend({required String occasion, String? weather, String? style, double? lat, double? lon}) =>
      _guard(() async {
        final r = await _dio.post('/recommend/', data: {
          'occasion': occasion,
          if (weather != null) 'weather': weather,
          if (style != null) 'style': style,
          if (lat != null) 'lat': lat,
          if (lon != null) 'lon': lon,
        });
        return Recommendation.fromJson(r.data);
      });

  Future<Weather> weather({double? lat, double? lon}) => _guard(() async {
        final r = await _dio.get('/weather/', queryParameters: {if (lat != null) 'lat': lat, if (lon != null) 'lon': lon});
        return Weather.fromJson(r.data);
      });

  Future<List<Outfit>> outfits({bool savedOnly = true}) => _guard(() async {
        final r = await _dio.get('/outfits/', queryParameters: {if (savedOnly) 'is_saved': true});
        return _results(r.data).map((e) => Outfit.fromJson(e)).toList();
      });

  Future<void> feedback(int outfitId, bool liked, {String reason = ''}) =>
      _guard(() => _dio.post('/outfits/$outfitId/feedback/', data: {'liked': liked, 'reason': reason}));

  Future<void> wear(int outfitId) => _guard(() => _dio.post('/outfits/$outfitId/wear/'));

  Future<Analytics> analytics() => _guard(() async => Analytics.fromJson((await _dio.get('/analytics/')).data));

  Future<String> chat(String message, List<ChatMsg> history) => _guard(() async {
        final r = await _dio.post('/chat/', data: {
          'message': message,
          'history': history.map((m) => {'role': m.role, 'content': m.text}).toList(),
        });
        return r.data['reply'] as String;
      });

  Future<void> deleteAccount() => _guard(() => _dio.delete('/me/'));
}

final apiProvider = Provider<Api>((ref) => Api(ref));

final wardrobeProvider = FutureProvider.autoDispose<List<ClothingItem>>((ref) => ref.watch(apiProvider).items());
final historyProvider = FutureProvider.autoDispose<List<Outfit>>((ref) => ref.watch(apiProvider).outfits());
final analyticsProvider = FutureProvider.autoDispose<Analytics>((ref) => ref.watch(apiProvider).analytics());
