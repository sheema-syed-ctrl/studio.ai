import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Palette drawn from the wardrobe itself: denim, linen, chambray, sage, ink.
class Palette {
  static const denim = Color(0xFF26407A);
  static const linen = Color(0xFFF6F7F9);
  static const chambray = Color(0xFFDCE5F2);
  static const sage = Color(0xFF5FA88F);
  static const ink = Color(0xFF151B2B);
  static const muted = Color(0xFF66708A);
}

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: Palette.denim,
    primary: Palette.denim,
    secondary: Palette.sage,
    surface: Palette.linen,
    onSurface: Palette.ink,
  );
  final body = GoogleFonts.manropeTextTheme();
  final serif = GoogleFonts.dmSerifDisplay;
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: Palette.linen,
    textTheme: body.copyWith(
      headlineMedium: serif(fontSize: 30, color: Palette.ink),
      headlineSmall: serif(fontSize: 24, color: Palette.ink),
      titleLarge: serif(fontSize: 20, color: Palette.ink),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: Palette.linen,
      elevation: 0,
      scrolledUnderElevation: 0,
      titleTextStyle: serif(fontSize: 22, color: Palette.ink),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.white,
      indicatorColor: Palette.chambray,
      labelTextStyle: WidgetStatePropertyAll(GoogleFonts.manrope(fontSize: 12, fontWeight: FontWeight.w600)),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size.fromHeight(52),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        textStyle: GoogleFonts.manrope(fontWeight: FontWeight.w700, fontSize: 15),
      ),
    ),
    chipTheme: ChipThemeData(
      selectedColor: Palette.denim,
      backgroundColor: Colors.white,
      labelStyle: GoogleFonts.manrope(fontWeight: FontWeight.w600),
      secondaryLabelStyle: GoogleFonts.manrope(fontWeight: FontWeight.w600, color: Colors.white),
      checkmarkColor: Colors.white,
      side: const BorderSide(color: Palette.chambray),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
    ),
  );
}
