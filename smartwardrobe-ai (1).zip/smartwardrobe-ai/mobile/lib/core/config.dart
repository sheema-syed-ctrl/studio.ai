/// Build-time configuration:
///   flutter run --dart-define=API_URL=http://10.0.2.2:8000/api --dart-define=USE_FIREBASE=false
class AppConfig {
  static const apiUrl = String.fromEnvironment('API_URL', defaultValue: 'http://10.0.2.2:8000/api');
  // false => "demo mode" using the backend's DEV_AUTH (local development only).
  static const useFirebase = bool.fromEnvironment('USE_FIREBASE', defaultValue: false);
}
