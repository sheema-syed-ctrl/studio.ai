import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'config.dart';

enum AuthStatus { signedOut, signedIn }

class AuthState {
  final AuthStatus status;
  final String? error;
  final bool busy;
  const AuthState({this.status = AuthStatus.signedOut, this.error, this.busy = false});
}

class AuthController extends Notifier<AuthState> {
  String? _devUid;

  @override
  AuthState build() {
    if (AppConfig.useFirebase && FirebaseAuth.instance.currentUser != null) {
      return const AuthState(status: AuthStatus.signedIn);
    }
    return const AuthState();
  }

  /// Authorization header value for the Django API.
  Future<String?> authHeader() async {
    if (!AppConfig.useFirebase) return _devUid == null ? null : 'Dev $_devUid';
    final token = await FirebaseAuth.instance.currentUser?.getIdToken();
    return token == null ? null : 'Bearer $token';
  }

  Future<void> _run(Future<void> Function() action) async {
    state = const AuthState(busy: true);
    try {
      await action();
      state = const AuthState(status: AuthStatus.signedIn);
    } on FirebaseAuthException catch (e) {
      state = AuthState(error: _friendly(e.code));
    } catch (_) {
      state = const AuthState(error: 'Something went wrong. Check your connection and try again.');
    }
  }

  Future<void> demo() => _run(() async => _devUid = 'demo');

  Future<void> signInEmail(String email, String password) =>
      _run(() => FirebaseAuth.instance.signInWithEmailAndPassword(email: email.trim(), password: password));

  Future<void> register(String email, String password) =>
      _run(() => FirebaseAuth.instance.createUserWithEmailAndPassword(email: email.trim(), password: password));

  Future<void> google() => _run(() async {
        final account = await GoogleSignIn().signIn();
        if (account == null) throw FirebaseAuthException(code: 'cancelled');
        final auth = await account.authentication;
        await FirebaseAuth.instance.signInWithCredential(
            GoogleAuthProvider.credential(accessToken: auth.accessToken, idToken: auth.idToken));
      });

  Future<void> resetPassword(String email) async {
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email.trim());
      state = const AuthState(error: 'Password reset email sent.');
    } on FirebaseAuthException catch (e) {
      state = AuthState(error: _friendly(e.code));
    }
  }

  Future<void> signOut() async {
    if (AppConfig.useFirebase) {
      await FirebaseAuth.instance.signOut();
      await GoogleSignIn().signOut();
    }
    _devUid = null;
    state = const AuthState();
  }

  String _friendly(String code) => switch (code) {
        'invalid-credential' || 'wrong-password' || 'user-not-found' => 'Email or password is incorrect.',
        'email-already-in-use' => 'An account with this email already exists. Sign in instead.',
        'weak-password' => 'Use a password with at least 6 characters.',
        'invalid-email' => 'Enter a valid email address.',
        'network-request-failed' => 'No connection. Check your internet and try again.',
        'cancelled' => 'Google sign-in was cancelled.',
        _ => 'Sign-in failed. Try again.',
      };
}

final authProvider = NotifierProvider<AuthController, AuthState>(AuthController.new);
