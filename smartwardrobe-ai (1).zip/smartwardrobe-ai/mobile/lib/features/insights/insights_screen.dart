import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/api.dart';
import '../../core/theme.dart';
import '../../models/models.dart';
import '../../widgets/common.dart';

class InsightsScreen extends ConsumerWidget {
  const InsightsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final data = ref.watch(analyticsProvider);
    return data.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => ErrorState(e, onRetry: () => ref.invalidate(analyticsProvider)),
      data: (a) => a.total == 0
          ? const EmptyState(icon: Icons.insights, title: 'Insights appear with your wardrobe', body: 'Add clothes and log what you wear to see patterns.')
          : RefreshIndicator(
              onRefresh: () async => ref.refresh(analyticsProvider.future),
              child: ListView(padding: const EdgeInsets.fromLTRB(20, 4, 20, 24), children: [
                Row(children: [
                  _Stat('${a.total}', 'pieces'),
                  _Stat('${a.outfitsWorn}', 'outfits worn'),
                  _Stat(a.likeRate == null ? '-' : '${(a.likeRate! * 100).round()}%', 'liked'),
                ]),
                const SizedBox(height: 20),
                if (a.gaps.isNotEmpty)
                  _Note('Missing: ${a.gaps.join(', ')}. Adding these unlocks more outfits.'),
                const _Heading('Colours you own'),
                for (final c in a.topColors) _Bar(label: c.key, value: c.value, max: a.topColors.first.value),
                const SizedBox(height: 16),
                const _Heading('Most worn'),
                if (a.mostWorn.isEmpty) const Text('Log an outfit to start tracking.', style: TextStyle(color: Palette.muted)),
                _Strip(a.mostWorn, showCount: true),
                const SizedBox(height: 16),
                _Heading('Not worn in 60 days (${a.unusedCount})'),
                _Strip(a.unused),
              ]),
            ),
    );
  }
}

class _Stat extends StatelessWidget {
  final String value, label;
  const _Stat(this.value, this.label);
  @override
  Widget build(BuildContext context) => Expanded(
        child: Container(
          margin: const EdgeInsets.only(right: 8),
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
          child: Column(children: [
            Text(value, style: Theme.of(context).textTheme.headlineSmall),
            Text(label, style: const TextStyle(color: Palette.muted, fontSize: 12)),
          ]),
        ),
      );
}

class _Heading extends StatelessWidget {
  final String text;
  const _Heading(this.text);
  @override
  Widget build(BuildContext context) =>
      Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(text, style: Theme.of(context).textTheme.titleLarge));
}

class _Note extends StatelessWidget {
  final String text;
  const _Note(this.text);
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: Palette.chambray, borderRadius: BorderRadius.circular(14)),
        child: Text(text),
      );
}

class _Bar extends StatelessWidget {
  final String label;
  final int value, max;
  const _Bar({required this.label, required this.value, required this.max});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Row(children: [
          SizedBox(width: 80, child: Text(label)),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(value: value / max, minHeight: 12, color: Palette.denim, backgroundColor: Palette.chambray),
            ),
          ),
          SizedBox(width: 32, child: Text('$value', textAlign: TextAlign.end)),
        ]),
      );
}

class _Strip extends StatelessWidget {
  final List<ClothingItem> items;
  final bool showCount;
  const _Strip(this.items, {this.showCount = false});
  @override
  Widget build(BuildContext context) => items.isEmpty
      ? const SizedBox.shrink()
      : SizedBox(
          height: 120,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (_, i) => Column(children: [
              ItemImage(items[i].imageSrc, size: 84),
              const SizedBox(height: 4),
              Text(showCount ? '${items[i].timesWorn}x' : items[i].primaryColor, style: const TextStyle(fontSize: 12, color: Palette.muted)),
            ]),
          ),
        );
}
