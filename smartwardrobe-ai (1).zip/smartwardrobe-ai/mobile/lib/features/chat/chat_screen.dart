import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/api.dart';
import '../../core/theme.dart';
import '../../models/models.dart';

class ChatScreen extends ConsumerStatefulWidget {
  const ChatScreen({super.key});
  @override
  ConsumerState<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends ConsumerState<ChatScreen> {
  final _ctl = TextEditingController();
  final _scroll = ScrollController();
  final List<ChatMsg> _msgs = [const ChatMsg('assistant', 'Ask me what to wear. I only suggest clothes from your wardrobe.')];
  bool _busy = false;

  static const _quick = ['What should I wear to college?', 'Something for a date', 'Office outfit'];

  @override
  void dispose() {
    _ctl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _send(String text) async {
    final msg = text.trim();
    if (msg.isEmpty || _busy) return;
    final history = _msgs.skip(1).toList(); // skip the greeting
    setState(() {
      _msgs.add(ChatMsg('user', msg));
      _busy = true;
      _ctl.clear();
    });
    try {
      final reply = await ref.read(apiProvider).chat(msg, history);
      setState(() => _msgs.add(ChatMsg('assistant', reply)));
    } catch (e) {
      setState(() => _msgs.add(ChatMsg('assistant', 'Sorry, I could not answer: $e')));
    } finally {
      if (mounted) setState(() => _busy = false);
      await Future.delayed(const Duration(milliseconds: 50));
      if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
    }
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        Expanded(
          child: ListView.builder(
            controller: _scroll,
            padding: const EdgeInsets.all(16),
            itemCount: _msgs.length + (_busy ? 1 : 0),
            itemBuilder: (_, i) {
              if (i == _msgs.length) return const Align(alignment: Alignment.centerLeft, child: Padding(padding: EdgeInsets.all(8), child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))));
              final m = _msgs[i];
              final mine = m.role == 'user';
              return Align(
                alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(color: mine ? Palette.denim : Colors.white, borderRadius: BorderRadius.circular(16)),
                  child: Text(m.text, style: TextStyle(color: mine ? Colors.white : Palette.ink, height: 1.4)),
                ),
              );
            },
          ),
        ),
        SizedBox(
          height: 44,
          child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
            for (final q in _quick) Padding(padding: const EdgeInsets.only(right: 8), child: ActionChip(label: Text(q), onPressed: () => _send(q))),
          ]),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
            child: Row(children: [
              Expanded(child: TextField(controller: _ctl, maxLength: 600, onSubmitted: _send, decoration: const InputDecoration(hintText: 'Ask your stylist', counterText: ''))),
              const SizedBox(width: 8),
              IconButton.filled(onPressed: _busy ? null : () => _send(_ctl.text), icon: const Icon(Icons.arrow_upward)),
            ]),
          ),
        ),
      ]);
}
