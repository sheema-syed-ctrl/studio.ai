import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/api.dart';
import '../../core/theme.dart';
import '../../models/models.dart';
import '../../widgets/common.dart';
import 'add_item_sheet.dart';
import 'item_detail.dart';

class WardrobeScreen extends ConsumerStatefulWidget {
  const WardrobeScreen({super.key});
  @override
  ConsumerState<WardrobeScreen> createState() => _WardrobeScreenState();
}

class _WardrobeScreenState extends ConsumerState<WardrobeScreen> {
  String _filter = 'all';
  static const _filters = ['all', 'top', 'bottom', 'outerwear', 'footwear', 'accessory'];

  @override
  Widget build(BuildContext context) {
    final items = ref.watch(wardrobeProvider);
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: Palette.denim,
        foregroundColor: Colors.white,
        onPressed: () async {
          final added = await showModalBottomSheet<bool>(
            context: context,
            isScrollControlled: true,
            showDragHandle: true,
            builder: (_) => const AddItemSheet(),
          );
          if (added == true) ref.invalidate(wardrobeProvider);
        },
        icon: const Icon(Icons.add_a_photo_outlined),
        label: const Text('Add clothing'),
      ),
      body: Column(children: [
        SizedBox(
          height: 48,
          child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: [
            for (final f in _filters)
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(f == 'all' ? 'All' : '${f[0].toUpperCase()}${f.substring(1)}'),
                  selected: _filter == f,
                  onSelected: (_) => setState(() => _filter = f),
                ),
              ),
          ]),
        ),
        Expanded(
          child: items.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, _) => ErrorState(e, onRetry: () => ref.invalidate(wardrobeProvider)),
            data: (all) {
              final list = _filter == 'all' ? all : all.where((i) => i.category == _filter).toList();
              if (all.isEmpty) {
                return const EmptyState(
                  icon: Icons.add_a_photo_outlined,
                  title: 'Start with three pieces',
                  body: 'Photograph a top, a bottom and a pair of shoes. We detect colour and type for you.',
                );
              }
              if (list.isEmpty) {
                return const EmptyState(icon: Icons.search_off, title: 'Nothing here yet', body: 'No items in this category.');
              }
              return RefreshIndicator(
                onRefresh: () async => ref.refresh(wardrobeProvider.future),
                child: GridView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2, mainAxisSpacing: 14, crossAxisSpacing: 14, childAspectRatio: 0.82),
                  itemCount: list.length,
                  itemBuilder: (_, i) => _Tile(item: list[i]),
                ),
              );
            },
          ),
        ),
      ]),
    );
  }
}

class _Tile extends ConsumerWidget {
  final ClothingItem item;
  const _Tile({required this.item});

  @override
  Widget build(BuildContext context, WidgetRef ref) => GestureDetector(
        onTap: () async {
          final changed = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => ItemDetailScreen(item: item)));
          if (changed == true) ref.invalidate(wardrobeProvider);
        },
        child: Container(
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
          padding: const EdgeInsets.all(8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(
              child: Stack(children: [
                Positioned.fill(child: ItemImage(item.imageSrc)),
                if (item.needsReview)
                  const Positioned(
                    top: 6,
                    left: 6,
                    child: Chip(label: Text('Check details'), visualDensity: VisualDensity.compact, backgroundColor: Colors.white),
                  ),
                if (item.isFavorite) const Positioned(top: 6, right: 6, child: Icon(Icons.favorite, color: Palette.sage, size: 20)),
              ]),
            ),
            const SizedBox(height: 8),
            Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
            Text('${item.primaryColor} · ${item.category}', style: const TextStyle(color: Palette.muted, fontSize: 12)),
          ]),
        ),
      );
}
