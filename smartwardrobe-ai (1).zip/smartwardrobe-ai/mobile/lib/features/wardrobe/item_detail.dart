import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/api.dart';
import '../../core/theme.dart';
import '../../models/models.dart';
import '../../widgets/common.dart';
import 'add_item_sheet.dart' show categories;

const _colors = ['white', 'black', 'grey', 'navy', 'blue', 'light blue', 'red', 'maroon', 'pink', 'orange', 'yellow', 'green', 'olive', 'teal', 'purple', 'brown', 'beige', 'cream', 'khaki'];

class ItemDetailScreen extends ConsumerStatefulWidget {
  final ClothingItem item;
  const ItemDetailScreen({super.key, required this.item});
  @override
  ConsumerState<ItemDetailScreen> createState() => _ItemDetailScreenState();
}

class _ItemDetailScreenState extends ConsumerState<ItemDetailScreen> {
  late String _category = categories.contains(widget.item.category) ? widget.item.category : 'top';
  late String _color = _colors.contains(widget.item.primaryColor) ? widget.item.primaryColor : 'white';
  late double _formality = widget.item.formality.toDouble();
  late bool _fav = widget.item.isFavorite;
  bool _busy = false;

  Future<void> _save() async {
    setState(() => _busy = true);
    try {
      await ref.read(apiProvider).updateItem(widget.item.id, {
        'category': _category,
        'primary_color': _color,
        'formality': _formality.round(),
        'is_favorite': _fav,
      });
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) toast(context, e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Remove this item?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Keep')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Remove')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await ref.read(apiProvider).deleteItem(widget.item.id);
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) toast(context, e.toString());
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(actions: [
          IconButton(onPressed: () => setState(() => _fav = !_fav), icon: Icon(_fav ? Icons.favorite : Icons.favorite_border, color: Palette.sage)),
          IconButton(onPressed: _delete, icon: const Icon(Icons.delete_outline)),
        ]),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          SizedBox(height: 280, child: ItemImage(widget.item.imageSrc, radius: BorderRadius.circular(20))),
          const SizedBox(height: 16),
          Text(widget.item.name, style: Theme.of(context).textTheme.headlineSmall),
          if (widget.item.needsReview)
            const Padding(
              padding: EdgeInsets.only(top: 6),
              child: Text('Detected automatically. Correct anything that looks off.', style: TextStyle(color: Palette.muted)),
            ),
          const SizedBox(height: 18),
          DropdownButtonFormField<String>(
            value: _category,
            decoration: const InputDecoration(labelText: 'Type'),
            items: [for (final c in categories) DropdownMenuItem(value: c, child: Text(c))],
            onChanged: (v) => setState(() => _category = v ?? _category),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _color,
            decoration: const InputDecoration(labelText: 'Main colour'),
            items: [for (final c in _colors) DropdownMenuItem(value: c, child: Text(c))],
            onChanged: (v) => setState(() => _color = v ?? _color),
          ),
          const SizedBox(height: 16),
          Text('Formality: ${_formality.round()} (1 loungewear to 5 formal)', style: const TextStyle(fontWeight: FontWeight.w700)),
          Slider(value: _formality, min: 1, max: 5, divisions: 4, onChanged: (v) => setState(() => _formality = v)),
          Text('Worn ${widget.item.timesWorn} times', style: const TextStyle(color: Palette.muted)),
          const SizedBox(height: 20),
          FilledButton(onPressed: _busy ? null : _save, child: const Text('Save changes')),
        ]),
      );
}
