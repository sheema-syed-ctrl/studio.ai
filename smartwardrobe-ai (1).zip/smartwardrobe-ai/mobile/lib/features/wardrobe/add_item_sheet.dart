import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import '../../core/api.dart';
import '../../core/config.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';

const categories = ['top', 'bottom', 'outerwear', 'footwear', 'accessory'];

class AddItemSheet extends ConsumerStatefulWidget {
  const AddItemSheet({super.key});
  @override
  ConsumerState<AddItemSheet> createState() => _AddItemSheetState();
}

class _AddItemSheetState extends ConsumerState<AddItemSheet> {
  File? _file;
  String? _category; // optional: AI fills it when empty
  final _name = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _pick(ImageSource source) async {
    final picked = await ImagePicker().pickImage(source: source, maxWidth: 2000, imageQuality: 95);
    if (picked == null) return;
    // Compress before upload: ~1024px JPEG keeps AI accuracy and saves bandwidth/storage.
    final dir = await getTemporaryDirectory();
    final out = '${dir.path}/${DateTime.now().microsecondsSinceEpoch}.jpg';
    final compressed = await FlutterImageCompress.compressAndGetFile(picked.path, out, minWidth: 1024, minHeight: 1024, quality: 82);
    setState(() => _file = File(compressed?.path ?? picked.path));
  }

  Future<void> _save() async {
    final file = _file;
    if (file == null) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final fields = <String, dynamic>{
        if (_name.text.trim().isNotEmpty) 'name': _name.text.trim(),
        if (_category != null) 'category': _category,
      };
      final api = ref.read(apiProvider);
      if (AppConfig.useFirebase) {
        final uid = FirebaseAuth.instance.currentUser!.uid;
        final ref0 = FirebaseStorage.instance.ref('users/$uid/items/${DateTime.now().microsecondsSinceEpoch}.jpg');
        await ref0.putFile(file, SettableMetadata(contentType: 'image/jpeg'));
        await api.addItem(imageUrl: await ref0.getDownloadURL(), fields: fields);
      } else {
        await api.addItem(file: file, fields: fields);
      }
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: EdgeInsets.fromLTRB(20, 0, 20, MediaQuery.of(context).viewInsets.bottom + 24),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text('Add clothing', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 4),
            const Text('Lay the item flat on a plain surface in good light.', style: TextStyle(color: Palette.muted)),
            const SizedBox(height: 14),
            if (_file != null)
              ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.file(_file!, height: 220, fit: BoxFit.cover))
            else
              Row(children: [
                Expanded(child: OutlinedButton.icon(onPressed: () => _pick(ImageSource.camera), icon: const Icon(Icons.photo_camera_outlined), label: const Text('Camera'))),
                const SizedBox(width: 12),
                Expanded(child: OutlinedButton.icon(onPressed: () => _pick(ImageSource.gallery), icon: const Icon(Icons.photo_library_outlined), label: const Text('Gallery'))),
              ]),
            const SizedBox(height: 14),
            TextField(controller: _name, decoration: const InputDecoration(labelText: 'Name (optional)')),
            const SizedBox(height: 12),
            Wrap(spacing: 8, children: [
              for (final c in categories)
                ChoiceChip(
                  label: Text(c),
                  selected: _category == c,
                  onSelected: (s) => setState(() => _category = s ? c : null),
                ),
            ]),
            const SizedBox(height: 6),
            const Text('Leave the type empty and we will detect it.', style: TextStyle(color: Palette.muted, fontSize: 12)),
            if (_error != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: (_file == null || _busy) ? null : _save,
              child: _busy ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Text('Save to wardrobe'),
            ),
          ]),
        ),
      );
}
