import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/api.dart';
import '../../core/auth.dart';
import '../chat/chat_screen.dart';
import '../history/history_screen.dart';
import '../insights/insights_screen.dart';
import '../today/today_screen.dart';
import '../wardrobe/wardrobe_screen.dart';
import '../../widgets/common.dart';

class HomeShell extends ConsumerStatefulWidget {
  const HomeShell({super.key});
  @override
  ConsumerState<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends ConsumerState<HomeShell> {
  int _index = 0;
  static const _titles = ['Today', 'Wardrobe', 'Saved looks', 'Insights', 'Stylist'];

  @override
  Widget build(BuildContext context) {
    final pages = [
      TodayScreen(onGoToWardrobe: () => setState(() => _index = 1)),
      const WardrobeScreen(),
      const HistoryScreen(),
      const InsightsScreen(),
      const ChatScreen(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_index]),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) async {
              if (v == 'out') {
                ref.read(authProvider.notifier).signOut();
              } else if (v == 'delete') {
                final ok = await showDialog<bool>(
                  context: context,
                  builder: (c) => AlertDialog(
                    title: const Text('Delete account?'),
                    content: const Text('This permanently deletes your wardrobe, outfits and history.'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Keep account')),
                      TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete everything')),
                    ],
                  ),
                );
                if (ok == true) {
                  try {
                    await ref.read(apiProvider).deleteAccount();
                    await ref.read(authProvider.notifier).signOut();
                  } catch (e) {
                    if (context.mounted) toast(context, e.toString());
                  }
                }
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'out', child: Text('Sign out')),
              PopupMenuItem(value: 'delete', child: Text('Delete account')),
            ],
          ),
        ],
      ),
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.wb_sunny_outlined), selectedIcon: Icon(Icons.wb_sunny), label: 'Today'),
          NavigationDestination(icon: Icon(Icons.checkroom_outlined), selectedIcon: Icon(Icons.checkroom), label: 'Wardrobe'),
          NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'Saved'),
          NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Insights'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Stylist'),
        ],
      ),
    );
  }
}
