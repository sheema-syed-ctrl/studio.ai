import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/api.dart';
import '../../core/theme.dart';
import '../../models/models.dart';
import '../../widgets/common.dart';

class HistoryScreen extends ConsumerWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final outfits = ref.watch(historyProvider);
    return outfits.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => ErrorState(e, onRetry: () => ref.invalidate(historyProvider)),
      data: (list) => list.isEmpty
          ? const EmptyState(
              icon: Icons.favorite_border,
              title: 'No saved looks yet',
              body: 'Tap the heart on an outfit you like, or log what you wore, and it shows up here.',
            )
          : RefreshIndicator(
              onRefresh: () async => ref.refresh(historyProvider.future),
              child: ListView.builder(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                itemCount: list.length,
                itemBuilder: (_, i) => _Row(outfit: list[i]),
              ),
            ),
    );
  }
}

class _Row extends StatelessWidget {
  final Outfit outfit;
  const _Row({required this.outfit});

  @override
  Widget build(BuildContext context) {
    final d = outfit.createdAt?.toLocal();
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
      child: Row(children: [
        for (final it in outfit.items.take(4))
          Padding(padding: const EdgeInsets.only(right: 6), child: ItemImage(it.imageSrc, size: 58, radius: BorderRadius.circular(10))),
        const Spacer(),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(outfit.occasion.isEmpty ? 'Outfit' : '${outfit.occasion[0].toUpperCase()}${outfit.occasion.substring(1)}',
              style: const TextStyle(fontWeight: FontWeight.w700)),
          if (d != null) Text('${d.day}/${d.month}/${d.year}', style: const TextStyle(color: Palette.muted, fontSize: 12)),
          if (outfit.liked != null) Icon(outfit.liked! ? Icons.favorite : Icons.thumb_down_outlined, size: 16, color: Palette.sage),
        ]),
      ]),
    );
  }
}
