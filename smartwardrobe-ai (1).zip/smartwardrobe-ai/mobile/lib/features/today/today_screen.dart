import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';
import '../../core/api.dart';
import '../../core/theme.dart';
import '../../models/models.dart';
import '../../widgets/common.dart';
import '../../widgets/outfit_card.dart';

const occasions = ['College', 'Work', 'Casual', 'Party', 'Date', 'Gym', 'Formal', 'Travel'];
const styles = ['Casual', 'Smart', 'Sporty', 'Streetwear', 'Minimal'];
const weatherOptions = ['Auto', 'Cold', 'Cool', 'Warm', 'Hot', 'Rainy'];

class TodayScreen extends ConsumerStatefulWidget {
  final VoidCallback onGoToWardrobe;
  const TodayScreen({super.key, required this.onGoToWardrobe});
  @override
  ConsumerState<TodayScreen> createState() => _TodayScreenState();
}

class _TodayScreenState extends ConsumerState<TodayScreen> {
  String _occasion = 'College', _style = 'Casual', _weather = 'Auto';
  bool _loading = false;
  Object? _error;
  Recommendation? _result;

  Future<({double? lat, double? lon})> _location() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) return (lat: null, lon: null);
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) return (lat: null, lon: null);
      final p = await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(accuracy: LocationAccuracy.low, timeLimit: Duration(seconds: 6)));
      return (lat: p.latitude, lon: p.longitude);
    } catch (_) {
      return (lat: null, lon: null); // weather falls back gracefully on the server
    }
  }

  Future<void> _suggest() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final loc = _weather == 'Auto' ? await _location() : (lat: null, lon: null);
      final res = await ref.read(apiProvider).recommend(
            occasion: _occasion.toLowerCase(),
            style: _style.toLowerCase(),
            weather: _weather == 'Auto' ? null : _weather.toLowerCase(),
            lat: loc.lat,
            lon: loc.lon,
          );
      if (mounted) setState(() => _result = res);
    } catch (e) {
      if (mounted) setState(() => _error = e);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _act(Future<void> Function() call, String done) async {
    try {
      await call();
      ref.invalidate(historyProvider);
      ref.invalidate(analyticsProvider);
      ref.invalidate(wardrobeProvider);
      if (mounted) toast(context, done);
    } catch (e) {
      if (mounted) toast(context, e.toString());
    }
  }

  Widget _chips(List<String> options, String selected, void Function(String) onPick) => Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          for (final o in options)
            ChoiceChip(label: Text(o), selected: o == selected, onSelected: (_) => onPick(o)),
        ],
      );

  @override
  Widget build(BuildContext context) {
    final api = ref.read(apiProvider);
    final res = _result;
    return ListView(padding: const EdgeInsets.fromLTRB(20, 4, 20, 24), children: [
      Text('Where are you headed?', style: Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height: 12),
      _chips(occasions, _occasion, (v) => setState(() => _occasion = v)),
      const SizedBox(height: 18),
      const Text('Weather', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      _chips(weatherOptions, _weather, (v) => setState(() => _weather = v)),
      const SizedBox(height: 18),
      const Text('Style', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      _chips(styles, _style, (v) => setState(() => _style = v)),
      const SizedBox(height: 22),
      FilledButton(
        onPressed: _loading ? null : _suggest,
        child: _loading
            ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
            : Text(res == null ? 'Suggest outfits' : 'Show me different outfits'),
      ),
      const SizedBox(height: 22),
      if (_error != null) Text(_error.toString(), style: TextStyle(color: Theme.of(context).colorScheme.error)),
      if (res != null && res.outfits.isEmpty)
        EmptyState(
          icon: Icons.checkroom,
          title: 'Your wardrobe needs a few more pieces',
          body: res.message.isEmpty ? 'Add clothes to get outfit ideas.' : res.message,
          action: 'Add clothes',
          onAction: widget.onGoToWardrobe,
        ),
      if (res != null && res.outfits.isNotEmpty) ...[
        Container(
          padding: const EdgeInsets.all(12),
          margin: const EdgeInsets.only(bottom: 14),
          decoration: BoxDecoration(color: Palette.chambray, borderRadius: BorderRadius.circular(14)),
          child: Row(children: [
            Icon(res.weather.rain ? Icons.umbrella : Icons.thermostat, color: Palette.denim),
            const SizedBox(width: 10),
            Expanded(
              child: Text('${res.weather.tempC.round()}°C · ${res.weather.band}${res.weather.rain ? ' · rain expected' : ''}'
                  '${res.weather.source == 'mock' ? ' (estimated)' : ''}'),
            ),
          ]),
        ),
        for (final o in res.outfits)
          OutfitCard(
            outfit: o,
            onWear: () => _act(() => api.wear(o.id), 'Logged. Have a great day!'),
            onLike: () => _act(() => api.feedback(o.id, true), 'Saved to your looks'),
            onDislike: () => _act(() => api.feedback(o.id, false), 'Got it, we will suggest fewer like this'),
          ),
      ],
    ]);
  }
}
