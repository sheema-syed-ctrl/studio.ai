import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../models/models.dart';
import 'common.dart';

/// A flat-lay: each garment sits on chambray with a small hang-tag label, like laying clothes out on a bed.
class OutfitCard extends StatelessWidget {
  final Outfit outfit;
  final VoidCallback? onWear, onLike, onDislike;
  const OutfitCard({super.key, required this.outfit, this.onWear, this.onLike, this.onDislike});

  static const _order = ['outerwear', 'top', 'bottom', 'footwear', 'accessory'];

  @override
  Widget build(BuildContext context) {
    final items = [...outfit.items]..sort((a, b) => _order.indexOf(a.category).compareTo(_order.indexOf(b.category)));
    return Container(
      margin: const EdgeInsets.only(bottom: 18),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(
          height: 150,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (_, i) => Column(children: [
              ItemImage(items[i].imageSrc, size: 112),
              const SizedBox(height: 6),
              SizedBox(
                width: 112,
                child: Text(items[i].name,
                    maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Palette.ink)),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 10),
        Text(outfit.explanation, style: const TextStyle(color: Palette.muted, height: 1.4)),
        const SizedBox(height: 12),
        Row(children: [
          IconButton.outlined(
            tooltip: 'Not for me',
            onPressed: onDislike,
            icon: Icon(outfit.liked == false ? Icons.thumb_down : Icons.thumb_down_outlined),
          ),
          const SizedBox(width: 8),
          IconButton.outlined(
            tooltip: 'Love it',
            onPressed: onLike,
            icon: Icon(outfit.liked == true ? Icons.favorite : Icons.favorite_border, color: Palette.sage),
          ),
          const SizedBox(width: 12),
          Expanded(child: FilledButton(onPressed: onWear, child: const Text('Wear this today'))),
        ]),
      ]),
    );
  }
}
