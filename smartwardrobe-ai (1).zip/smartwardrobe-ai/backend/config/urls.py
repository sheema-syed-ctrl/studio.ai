from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.http import JsonResponse
from django.urls import include, path

def health(_request):
    return JsonResponse({"status": "ok", "service": "smartwardrobe-ai"})

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/health/", health),
    path("api/", include("apps.accounts.urls")),
    path("api/", include("apps.wardrobe.urls")),
    path("api/", include("apps.outfits.urls")),
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
