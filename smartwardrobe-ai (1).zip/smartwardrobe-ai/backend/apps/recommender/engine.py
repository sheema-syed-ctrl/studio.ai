"""Outfit recommendation engine: filter -> generate -> score -> diversify -> explain.

Only items the user owns are ever recommended. Scoring is transparent (no black box) so it can be
explained in a viva and later swapped for a learned ranker using the stored feedback data.
"""
from datetime import date
from itertools import product

from services.ai.taxonomy import OPEN_FOOTWEAR

from .colors import color_score

OCCASIONS = {  # occasion -> (min formality, max formality)
    "college": (1, 3), "casual": (1, 2), "office": (3, 5), "formal": (4, 5), "party": (2, 4),
    "date": (2, 4), "gym": (1, 1), "wedding": (4, 5), "travel": (1, 2),
}
IDEAL_WARMTH = {"hot": 1.0, "warm": 1.5, "mild": 2.5, "cool": 3.5, "cold": 4.5}
PER_CATEGORY = 6


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


def item_score(item, ctx, kind):
    lo, hi = OCCASIONS[ctx["occasion"]]
    f = item.formality
    formality_fit = 1.0 if lo <= f <= hi else max(0.0, 1 - 0.35 * (lo - f if f < lo else f - hi))
    ideal = IDEAL_WARMTH[ctx["weather"]["label"]]
    if kind in ("bottom", "footwear"):
        ideal = min(5, ideal + 0.5)
    if kind == "outerwear":
        ideal = min(5, ideal + 0.5)
    weather_fit = max(0.0, 1 - 0.2 * abs(item.warmth - ideal))
    if ctx["weather"]["is_raining"] and item.subcategory in OPEN_FOOTWEAR:
        weather_fit *= 0.3
    s = 0.5 * formality_fit + 0.5 * weather_fit
    if ctx["style"] and ctx["style"] in (item.style_tags or []):
        s += 0.15
    if ctx["occasion"] == "gym" and "sporty" in (item.style_tags or []):
        s += 0.2
    s += _clamp(ctx["item_pref"].get(item.id, 0), -3, 3) * 0.05
    if item.is_favorite:
        s += 0.05
    if item.last_worn:
        days = (ctx["today"] - item.last_worn).days
        s -= 0.2 if days <= 2 else 0.1 if days <= 5 else 0
    if item.primary_color in ctx["disliked_colors"]:
        s -= 0.3
    if item.primary_color in ctx["favorite_colors"]:
        s += 0.1
    return s


def _outfit_score(core, outer, ctx):
    pieces = core + ([outer] if outer else [])
    indiv = sum(item_score(i, ctx, i.category) for i in pieces) / len(pieces)
    col = color_score(pieces)
    fs = [i.formality for i in pieces if i.category != "accessory"]
    coherence = 1 - min(1, (max(fs) - min(fs)) / 4)
    pen = 0.3 if frozenset(i.id for i in core) in ctx["bad_combos"] else 0
    total = 0.55 * indiv + 0.30 * col + 0.15 * coherence - pen
    return total, {"items": round(indiv, 3), "color": round(col, 3), "coherence": round(coherence, 3)}


def _explain(pieces, ctx, breakdown):
    w = ctx["weather"]
    names = [p.display_name for p in pieces]
    listed = ", ".join(names[:-1]) + f" and {names[-1]}" if len(names) > 1 else names[0]
    parts = [f"{listed}: suits {ctx['occasion']} dress codes"]
    parts.append(f"works for {w['label']} weather ({w['temp_c']:.0f}°C)" + (" with rain" if w["is_raining"] else ""))
    parts.append("colours pair cleanly" if breakdown["color"] >= 0.85 else "bolder colour mix")
    return "; ".join(parts) + "."


def recommend(items, *, occasion, style="", weather, item_pref=None, bad_combos=None,
              favorite_colors=(), disliked_colors=(), count=3, today=None):
    ctx = {"occasion": occasion, "style": (style or "").lower(), "weather": weather,
           "item_pref": item_pref or {}, "bad_combos": bad_combos or set(),
           "favorite_colors": set(favorite_colors), "disliked_colors": set(disliked_colors),
           "today": today or date.today()}
    by_cat = {}
    for it in items:
        by_cat.setdefault(it.category, []).append(it)

    def top(cat):
        ranked = sorted(by_cat.get(cat, []), key=lambda i: -item_score(i, ctx, cat))
        return ranked[:PER_CATEGORY]

    tops, bottoms, dresses, shoes, outers = (top(c) for c in ("top", "bottom", "dress", "footwear", "outerwear"))
    gaps = []
    if not shoes:
        gaps.append("footwear")
    if not (dresses or (tops and bottoms)):
        gaps.extend(c for c, lst in (("top", tops), ("bottom", bottoms)) if not lst)

    cores = [list(c) for c in product(tops, bottoms, shoes or [None])] + \
            [list(c) for c in product(dresses, shoes or [None])]
    cores = [[p for p in c if p] for c in cores if c and all(p is not None or True for p in c)]
    cores = [c for c in cores if any(p.category in ("top", "dress") for p in c)]
    if not cores:
        return {"outfits": [], "gaps": sorted(set(gaps)), "notes": ["Add more clothes to get outfits."]}

    w = weather
    needs_outer = (w["temp_c"] <= 18 or w["is_raining"]) and w["label"] != "hot"
    notes = []
    if needs_outer and not outers:
        notes.append("It's cool or rainy: a jacket or raincoat would complete this look (none in your wardrobe).")
    best_outer = outers[0] if (needs_outer and outers) else None
    if w["is_raining"] and outers:
        rain = [o for o in outers if o.subcategory == "raincoat"]
        best_outer = rain[0] if rain else best_outer

    scored = []
    for c in cores:
        s, br = _outfit_score(c, best_outer, ctx)
        scored.append((s, br, c))
    scored.sort(key=lambda x: -x[0])

    chosen = []
    for s, br, c in scored:
        ids = {p.id for p in c}
        if all(len(ids & {p.id for p in o[2]}) < 2 for o in chosen) or len(c) == 1:
            chosen.append((s, br, c))
        if len(chosen) == count:
            break
    for x in scored:  # top up if diversity filter left gaps
        if len(chosen) >= count:
            break
        if x not in chosen:
            chosen.append(x)

    out = []
    for s, br, c in chosen:
        pieces = c + ([best_outer] if best_outer else [])
        out.append({"items": pieces, "score": round(s, 3), "breakdown": br, "explanation": _explain(pieces, ctx, br)})
    return {"outfits": out, "gaps": sorted(set(gaps)), "notes": notes}
