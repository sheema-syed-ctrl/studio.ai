from rest_framework import serializers

from apps.weather.service import LABELS

from .engine import OCCASIONS


class RecommendRequest(serializers.Serializer):
    occasion = serializers.ChoiceField(choices=list(OCCASIONS))
    style = serializers.CharField(required=False, allow_blank=True, max_length=20, default="")
    weather = serializers.ChoiceField(choices=LABELS + ["rainy"], required=False)
    temp_c = serializers.FloatField(required=False, min_value=-40, max_value=55)
    lat = serializers.FloatField(required=False, min_value=-90, max_value=90)
    lon = serializers.FloatField(required=False, min_value=-180, max_value=180)
    count = serializers.IntegerField(required=False, min_value=1, max_value=5, default=3)
