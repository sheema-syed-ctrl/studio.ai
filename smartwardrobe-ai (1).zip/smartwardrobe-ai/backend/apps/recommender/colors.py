"""Colour compatibility using hue relationships on the colour wheel."""
import colorsys
from itertools import combinations

NEUTRAL_NAMES = {"white", "black", "grey", "beige", "navy", "brown", "cream", "khaki"}


def _hls(hexcode):
    h = hexcode.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
    hue, l, s = colorsys.rgb_to_hls(r, g, b)
    return hue * 360, l, s


def is_neutral(name, hexcode):
    if name in NEUTRAL_NAMES:
        return True
    _, l, s = _hls(hexcode)
    return s < 0.18 or l < 0.14 or l > 0.9


def _pair_score(h1, h2):
    d = abs(h1 - h2)
    d = min(d, 360 - d)
    if d <= 30:
        return 1.0   # analogous / monochrome
    if d >= 150:
        return 0.9   # complementary
    if 100 <= d <= 140:
        return 0.55  # triadic: workable but busy
    return 0.35      # awkward in-between hues


def color_score(items):
    """items: iterable of objects with primary_color, primary_hex, pattern. Returns 0..1."""
    chromatic = [(i.primary_hex and _hls(i.primary_hex)[0]) for i in items
                 if not is_neutral(i.primary_color, i.primary_hex)]
    score = 1.0
    if len(chromatic) >= 2:
        pairs = [_pair_score(a, b) for a, b in combinations(chromatic, 2)]
        score = sum(pairs) / len(pairs)
    if len(chromatic) >= 3:
        score *= 0.8
    patterned = sum(1 for i in items if i.pattern != "solid")
    if patterned >= 2:
        score -= 0.25
    return max(0.0, min(1.0, score))
