from django.urls import path

from .views import OptionsView, RecommendView

urlpatterns = [path("recommendations/", RecommendView.as_view()), path("options/", OptionsView.as_view())]
