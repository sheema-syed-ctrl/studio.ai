from rest_framework.response import Response
from rest_framework.views import APIView

from apps.outfits.services import preference_data
from apps.wardrobe.models import ClothingItem
from apps.wardrobe.serializers import ClothingItemSerializer
from apps.weather.service import resolve_weather

from .engine import OCCASIONS, recommend
from .serializers import RecommendRequest


def run_recommendation(user, occasion, style="", weather=None, temp_c=None, lat=None, lon=None, count=3):
    wx = resolve_weather(label=weather, temp_c=temp_c, lat=lat, lon=lon)
    item_pref, bad = preference_data(user)
    prof = user.profile
    result = recommend(
        list(ClothingItem.objects.filter(user=user)), occasion=occasion, style=style, weather=wx,
        item_pref=item_pref, bad_combos=bad, favorite_colors=prof.favorite_colors,
        disliked_colors=prof.disliked_colors, count=count)
    return wx, result


class RecommendView(APIView):
    def post(self, request):
        s = RecommendRequest(data=request.data)
        s.is_valid(raise_exception=True)
        d = s.validated_data
        wx, result = run_recommendation(request.user, d["occasion"], d["style"], d.get("weather"),
                                        d.get("temp_c"), d.get("lat"), d.get("lon"), d["count"])
        for o in result["outfits"]:
            o["items"] = ClothingItemSerializer(o["items"], many=True).data
        return Response({"weather": wx, **result})


class OptionsView(APIView):
    def get(self, request):
        return Response({"occasions": list(OCCASIONS), "weather": ["auto", "hot", "warm", "mild", "cool", "cold", "rainy"],
                         "styles": ["casual", "formal", "sporty", "streetwear", "ethnic", "minimal"]})
