from django.contrib import admin
from .models import Outfit, OutfitFeedback

admin.site.register(Outfit)
admin.site.register(OutfitFeedback)
