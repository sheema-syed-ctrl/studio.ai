from rest_framework import serializers
from apps.wardrobe.models import ClothingItem
from apps.wardrobe.serializers import ClothingItemSerializer
from .models import Outfit, OutfitFeedback


class OutfitSerializer(serializers.ModelSerializer):
    items = ClothingItemSerializer(many=True, read_only=True)
    item_ids = serializers.PrimaryKeyRelatedField(many=True, write_only=True, queryset=ClothingItem.objects.all(), source="items")
    feedback = serializers.SerializerMethodField()

    class Meta:
        model = Outfit
        fields = ["id", "items", "item_ids", "occasion", "weather", "score", "explanation",
                  "is_saved", "worn_on", "created_at", "feedback"]
        read_only_fields = ["id", "created_at", "worn_on"]

    def get_feedback(self, obj):
        fb = getattr(obj, "feedback", None)
        return {"liked": fb.liked, "reason": fb.reason} if fb else None

    def validate_item_ids(self, items):
        user = self.context["request"].user
        if not items or any(i.user_id != user.id for i in items):
            raise serializers.ValidationError("Items must be non-empty and belong to you")
        return items


class FeedbackSerializer(serializers.ModelSerializer):
    class Meta:
        model = OutfitFeedback
        fields = ["liked", "reason"]
