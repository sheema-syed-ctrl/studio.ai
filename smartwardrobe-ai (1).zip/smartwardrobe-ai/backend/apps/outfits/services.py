from .models import Feedback


def preference_data(user):
    """Learn from feedback: per-item like/dislike score and disliked item combinations."""
    item_pref, bad_combos = {}, set()
    fb = Feedback.objects.filter(user=user).select_related("outfit").prefetch_related("outfit__items")
    for f in fb:
        ids = [i.id for i in f.outfit.items.all()]
        delta = 1 if f.rating == "like" else -1
        for i in ids:
            item_pref[i] = item_pref.get(i, 0) + delta
        if delta < 0:
            bad_combos.add(frozenset(ids))
    return item_pref, bad_combos
