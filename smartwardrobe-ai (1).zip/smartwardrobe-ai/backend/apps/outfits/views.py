from collections import Counter
from datetime import date, timedelta
from django.db.models import F
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.wardrobe.models import ClothingItem
from apps.wardrobe.serializers import ClothingItemSerializer
from apps.accounts.throttles import AIThrottle
from services import recommender, weather as wx
from services.ai import chat
from .models import Outfit, OutfitFeedback
from .serializers import FeedbackSerializer, OutfitSerializer


def resolve_weather(request, data):
    if data.get("weather"):
        return wx.from_band(str(data["weather"]))
    u = request.user
    lat, lon = data.get("lat", u.latitude), data.get("lon", u.longitude)
    try:
        lat = float(lat) if lat is not None else None; lon = float(lon) if lon is not None else None
    except (TypeError, ValueError):
        lat = lon = None
    return wx.current(lat, lon)


def feedback_signal(user):
    liked, disliked, combos = set(), set(), set()
    for fb in OutfitFeedback.objects.filter(outfit__user=user).select_related("outfit").order_by("-created_at")[:60]:
        ids = set(fb.outfit.items.values_list("id", flat=True))
        (liked if fb.liked else disliked).update(ids)
        if not fb.liked:
            combos.add(tuple(sorted(ids)))  # never re-suggest an outfit the user rejected
    return {"liked": liked, "disliked": disliked - liked, "disliked_combos": combos}


class RecommendView(APIView):
    throttle_classes = [AIThrottle]

    def post(self, request):
        occasion = str(request.data.get("occasion", "casual")).lower()
        weather = resolve_weather(request, request.data)
        try:
            count = max(1, min(int(request.data.get("count", 3)), 6))
        except (TypeError, ValueError):
            count = 3
        if request.data.get("style"):
            request.user.style_tags = list({*request.user.style_tags, str(request.data["style"]).lower()})
        res = recommender.recommend(request.user, occasion, weather, count, feedback=feedback_signal(request.user))
        out = []
        for r in res["outfits"]:
            o = Outfit.objects.create(user=request.user, occasion=occasion, weather=weather,
                                      score=r["score"], explanation=r["explanation"])
            o.items.set(r["items"])
            data = OutfitSerializer(o, context={"request": request}).data
            data["breakdown"] = r["breakdown"]
            out.append(data)
        return Response({"weather": weather, "occasion": occasion, "outfits": out,
                         "missing": res["missing"], "message": res["message"]})


class OutfitViewSet(viewsets.ModelViewSet):
    serializer_class = OutfitSerializer
    http_method_names = ["get", "post", "patch", "delete", "head", "options"]
    filterset_fields = ["is_saved", "occasion"]

    def get_queryset(self):
        return Outfit.objects.filter(user=self.request.user).prefetch_related("items").select_related("feedback")

    def perform_create(self, serializer):
        serializer.save(user=self.request.user, is_saved=True)

    @action(detail=True, methods=["post"])
    def feedback(self, request, pk=None):
        outfit = self.get_object()
        ser = FeedbackSerializer(data=request.data); ser.is_valid(raise_exception=True)
        OutfitFeedback.objects.update_or_create(outfit=outfit, defaults=ser.validated_data)
        if ser.validated_data["liked"]:
            outfit.is_saved = True; outfit.save(update_fields=["is_saved"])
        return Response({"ok": True})

    @action(detail=True, methods=["post"])
    def wear(self, request, pk=None):
        """Mark as worn today: updates wear counters used for freshness + analytics."""
        outfit = self.get_object()
        if outfit.worn_on == date.today():
            return Response({"ok": True, "already": True})
        outfit.worn_on = date.today(); outfit.is_saved = True; outfit.save(update_fields=["worn_on", "is_saved"])
        ClothingItem.objects.filter(outfits=outfit).update(times_worn=F("times_worn") + 1, last_worn=date.today())
        return Response({"ok": True})


class AnalyticsView(APIView):
    def get(self, request):
        items = list(ClothingItem.objects.filter(user=request.user, is_archived=False))
        cutoff = date.today() - timedelta(days=60)
        unused = [i for i in items if not i.last_worn or i.last_worn < cutoff]
        colors = Counter(i.primary_color for i in items if i.primary_color)
        worn = sorted(items, key=lambda i: -i.times_worn)[:5]
        fb = OutfitFeedback.objects.filter(outfit__user=request.user)
        ctx = {"request": request}
        return Response({
            "total_items": len(items),
            "by_category": dict(Counter(i.category for i in items)),
            "top_colors": colors.most_common(5),
            "most_worn": ClothingItemSerializer([i for i in worn if i.times_worn], many=True, context=ctx).data,
            "unused_60d": ClothingItemSerializer(unused[:10], many=True, context=ctx).data,
            "unused_count": len(unused),
            "outfits_worn": Outfit.objects.filter(user=request.user, worn_on__isnull=False).count(),
            "like_rate": round(fb.filter(liked=True).count() / fb.count(), 2) if fb.exists() else None,
            "gaps": [c for c in ("top", "bottom", "footwear", "outerwear") if not any(i.category == c for i in items)],
        })


class WeatherView(APIView):
    def get(self, request):
        return Response(resolve_weather(request, request.query_params))


class ChatView(APIView):
    throttle_classes = [AIThrottle]

    def post(self, request):
        msg = str(request.data.get("message", "")).strip()[:600]
        if not msg:
            return Response({"detail": "message is required"}, status=400)
        history = request.data.get("history") if isinstance(request.data.get("history"), list) else []
        text, source = chat.reply(request.user, msg, history, resolve_weather(request, request.data))
        return Response({"reply": text, "source": source})
