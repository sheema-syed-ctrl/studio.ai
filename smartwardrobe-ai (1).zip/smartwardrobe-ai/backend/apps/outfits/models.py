from django.db import models


class Outfit(models.Model):
    user = models.ForeignKey("accounts.UserProfile", on_delete=models.CASCADE, related_name="outfits")
    items = models.ManyToManyField("wardrobe.ClothingItem", related_name="outfits")
    occasion = models.CharField(max_length=30, blank=True)
    weather = models.JSONField(default=dict, blank=True)
    score = models.FloatField(default=0)
    explanation = models.CharField(max_length=300, blank=True)
    is_saved = models.BooleanField(default=False)
    worn_on = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]


class OutfitFeedback(models.Model):
    outfit = models.OneToOneField(Outfit, on_delete=models.CASCADE, related_name="feedback")
    liked = models.BooleanField()
    reason = models.CharField(max_length=200, blank=True)  # e.g. "too hot", "colors clash"
    created_at = models.DateTimeField(auto_now_add=True)
