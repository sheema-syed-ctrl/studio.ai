from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import AnalyticsView, ChatView, OutfitViewSet, RecommendView, WeatherView

router = DefaultRouter()
router.register("outfits", OutfitViewSet, basename="outfit")
urlpatterns = [
    path("recommend/", RecommendView.as_view()),
    path("analytics/", AnalyticsView.as_view()),
    path("weather/", WeatherView.as_view()),
    path("chat/", ChatView.as_view()),
] + router.urls
