from urllib.parse import urlparse
from django.conf import settings
from rest_framework import serializers
from .models import ClothingItem


class ClothingItemSerializer(serializers.ModelSerializer):
    display_name = serializers.CharField(read_only=True)
    image_src = serializers.SerializerMethodField()
    analyze = serializers.BooleanField(write_only=True, required=False, default=True)

    class Meta:
        model = ClothingItem
        fields = ["id", "name", "display_name", "image", "image_url", "image_src", "cutout_url", "category",
                  "subcategory", "primary_color", "secondary_colors", "pattern", "material", "seasons",
                  "occasions", "formality", "warmth", "is_favorite", "is_archived", "ai_meta",
                  "times_worn", "last_worn", "created_at", "analyze"]
        read_only_fields = ["id", "times_worn", "last_worn", "created_at", "ai_meta", "cutout_url"]
        extra_kwargs = {"image": {"write_only": True, "required": False}}

    def get_image_src(self, obj):
        if obj.image_url:
            return obj.image_url
        if obj.image:
            req = self.context.get("request")
            return req.build_absolute_uri(obj.image.url) if req else obj.image.url
        return ""

    def validate_image_url(self, value):
        if value and (urlparse(value).scheme != "https" or urlparse(value).hostname not in settings.ALLOWED_IMAGE_HOSTS):
            raise serializers.ValidationError("Image URL must be an https Firebase Storage URL")
        return value

    def validate_formality(self, v):
        if not 1 <= v <= 5:
            raise serializers.ValidationError("Formality is 1-5")
        return v

    def validate_image(self, f):
        if f and f.size > 10 * 1024 * 1024:
            raise serializers.ValidationError("Image must be under 10 MB")
        return f

    def validate(self, attrs):
        if self.instance is None and not (attrs.get("image") or attrs.get("image_url")):
            raise serializers.ValidationError("Provide an image file or image_url")
        return attrs
