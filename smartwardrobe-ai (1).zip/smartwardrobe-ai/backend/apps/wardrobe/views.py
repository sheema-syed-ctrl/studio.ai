from django.db.models import Count
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.response import Response
from apps.accounts.throttles import AIThrottle
from services.ai import analyzer
from .models import ClothingItem
from .serializers import ClothingItemSerializer

AI_FIELDS = ["category", "subcategory", "primary_color", "secondary_colors", "pattern",
             "seasons", "occasions", "formality", "warmth"]


def run_analysis(item, remove_bg=False):
    """Fill only fields the user did not set; never overwrite user-provided values."""
    src = item.image_url or (item.image.open("rb").read() if item.image else None)
    if not src:
        return
    try:
        res = analyzer.analyze(src, remove_bg=remove_bg)
    except (analyzer.UnsafeURL, ValueError, OSError) as exc:
        item.ai_meta = {"error": str(exc)[:200]}
        return
    empty = lambda v: v in ("", None, [], "unknown")  # noqa: E731
    defaults = {"category": "unknown", "formality": 3, "warmth": 2}
    for f in AI_FIELDS:
        cur = getattr(item, f)
        if empty(cur) or (f in defaults and cur == defaults[f] and res.get(f) not in (None, "unknown")):
            if not empty(res.get(f)):
                setattr(item, f, res[f])
    item.ai_meta = {"confidence": res["confidence"], "source": res["source"]}


class ClothingItemViewSet(viewsets.ModelViewSet):
    serializer_class = ClothingItemSerializer
    parser_classes = [MultiPartParser, FormParser, JSONParser]
    filterset_fields = ["category", "primary_color", "is_favorite", "is_archived", "pattern"]
    ordering_fields = ["created_at", "times_worn", "last_worn"]

    def get_throttles(self):
        if self.action in ("create", "reanalyze"):
            return [AIThrottle()]
        return super().get_throttles()

    def get_queryset(self):  # object-level isolation: users only ever see their own items
        qs = ClothingItem.objects.filter(user=self.request.user)
        if self.action == "list" and "is_archived" not in self.request.query_params:
            qs = qs.filter(is_archived=False)
        return qs

    def perform_create(self, serializer):
        analyze = serializer.validated_data.pop("analyze", True)
        item = serializer.save(user=self.request.user)
        if analyze:
            run_analysis(item)
            item.save()

    @action(detail=True, methods=["post"])
    def reanalyze(self, request, pk=None):
        item = self.get_object()
        run_analysis(item, remove_bg=request.data.get("remove_background") in (True, "true", "1"))
        item.save()
        return Response(self.get_serializer(item).data)

    @action(detail=False, methods=["get"])
    def summary(self, request):
        qs = self.get_queryset().filter(is_archived=False)
        return Response({
            "total": qs.count(),
            "by_category": dict(qs.values_list("category").annotate(n=Count("id"))),
            "by_color": dict(qs.exclude(primary_color="").values_list("primary_color").annotate(n=Count("id"))),
        })
