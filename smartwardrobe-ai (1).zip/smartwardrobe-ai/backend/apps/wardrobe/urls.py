from rest_framework.routers import DefaultRouter
from .views import ClothingItemViewSet

router = DefaultRouter()
router.register("wardrobe/items", ClothingItemViewSet, basename="item")
urlpatterns = router.urls
