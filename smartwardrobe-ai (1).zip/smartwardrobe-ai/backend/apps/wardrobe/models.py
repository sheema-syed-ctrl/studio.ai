from django.conf import settings  # noqa: F401
from django.db import models


class ClothingItem(models.Model):
    class Category(models.TextChoices):
        TOP = "top"; BOTTOM = "bottom"; OUTERWEAR = "outerwear"
        FOOTWEAR = "footwear"; ACCESSORY = "accessory"; UNKNOWN = "unknown"

    user = models.ForeignKey("accounts.UserProfile", on_delete=models.CASCADE, related_name="items")
    name = models.CharField(max_length=120, blank=True)
    image = models.ImageField(upload_to="items/%Y/%m/", blank=True)          # dev/local uploads
    image_url = models.URLField(max_length=1000, blank=True)                 # Firebase Storage URL (prod)
    cutout_url = models.URLField(max_length=1000, blank=True)
    category = models.CharField(max_length=20, choices=Category.choices, default=Category.UNKNOWN, db_index=True)
    subcategory = models.CharField(max_length=40, blank=True)
    primary_color = models.CharField(max_length=30, blank=True, db_index=True)
    secondary_colors = models.JSONField(default=list, blank=True)
    pattern = models.CharField(max_length=20, blank=True)
    material = models.CharField(max_length=40, blank=True)
    seasons = models.JSONField(default=list, blank=True)
    occasions = models.JSONField(default=list, blank=True)
    formality = models.PositiveSmallIntegerField(default=3)   # 1 loungewear .. 5 black tie
    warmth = models.PositiveSmallIntegerField(default=2)      # 1 very light .. 4 heavy
    is_favorite = models.BooleanField(default=False)
    is_archived = models.BooleanField(default=False)
    ai_meta = models.JSONField(default=dict, blank=True)      # confidence/source of AI suggestion
    times_worn = models.PositiveIntegerField(default=0)
    last_worn = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["user", "category", "is_archived"])]

    def __str__(self):
        return self.name or f"{self.primary_color} {self.subcategory or self.category}"

    @property
    def display_name(self):
        return self.name or " ".join(x for x in (self.primary_color, self.subcategory or self.category) if x).title()
