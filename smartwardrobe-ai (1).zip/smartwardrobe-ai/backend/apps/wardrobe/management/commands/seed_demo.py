"""python manage.py seed_demo [uid]  -> creates a demo wardrobe (colour-swatch images) for Dev auth user."""
import io
from django.core.files.base import ContentFile
from django.core.management.base import BaseCommand
from PIL import Image, ImageDraw
from apps.accounts.models import UserProfile
from apps.wardrobe.models import ClothingItem

RGB = {"white": (245, 245, 245), "black": (25, 25, 25), "blue": (50, 100, 200), "navy": (25, 35, 90),
       "light blue": (160, 195, 235), "grey": (130, 130, 130), "beige": (225, 205, 170), "olive": (110, 120, 50),
       "red": (200, 50, 50)}
# (name, category, subcategory, color, formality, warmth, occasions)
DEMO = [
    ("White T-Shirt", "top", "t-shirt", "white", 2, 1, ["college", "casual"]),
    ("Black Hoodie", "top", "hoodie", "black", 2, 4, ["college", "casual", "gym"]),
    ("Light Blue Shirt", "top", "shirt", "light blue", 4, 1, ["work", "formal", "date"]),
    ("Grey Sweater", "top", "sweater", "grey", 3, 3, ["casual", "college", "work"]),
    ("Blue Jeans", "bottom", "jeans", "blue", 2, 2, ["college", "casual", "date"]),
    ("Black Trousers", "bottom", "trousers", "black", 4, 2, ["work", "formal"]),
    ("Beige Shorts", "bottom", "shorts", "beige", 2, 1, ["casual", "college", "travel"]),
    ("White Sneakers", "footwear", "sneakers", "white", 2, 2, ["college", "casual", "gym", "date"]),
    ("Black Formal Shoes", "footwear", "formal shoes", "black", 5, 2, ["work", "formal"]),
    ("Navy Jacket", "outerwear", "jacket", "navy", 3, 4, ["casual", "college", "date"]),
]


def swatch(color):
    img = Image.new("RGB", (400, 400), (238, 241, 246))
    ImageDraw.Draw(img).rounded_rectangle((60, 60, 340, 340), 40, fill=RGB[color])
    buf = io.BytesIO(); img.save(buf, "PNG"); return buf.getvalue()


class Command(BaseCommand):
    def add_arguments(self, parser):
        parser.add_argument("uid", nargs="?", default="demo")

    def handle(self, *args, **opts):
        user, _ = UserProfile.objects.get_or_create(firebase_uid=f"dev:{opts['uid']}", defaults={
            "email": f"{opts['uid']}@dev.local", "display_name": opts["uid"].title()})
        ClothingItem.objects.filter(user=user).delete()
        for name, cat, sub, col, form, warm, occ in DEMO:
            it = ClothingItem(user=user, name=name, category=cat, subcategory=sub, primary_color=col,
                              formality=form, warmth=warm, occasions=occ, pattern="solid",
                              seasons=["spring", "summer", "autumn", "winter"], ai_meta={"source": "seed"})
            it.image.save(f"{sub}.png", ContentFile(swatch(col)), save=False); it.save()
        self.stdout.write(self.style.SUCCESS(f"Seeded {len(DEMO)} items for dev user '{opts['uid']}'"))
