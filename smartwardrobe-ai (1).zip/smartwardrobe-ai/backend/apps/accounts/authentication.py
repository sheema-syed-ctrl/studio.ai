"""Verify Firebase ID tokens sent as `Authorization: Bearer <token>`.

DEV_AUTH (only honoured when DEBUG=1) accepts `Authorization: Dev <uid>` so the
backend can be exercised without Firebase credentials.
"""
import logging
from django.conf import settings
from rest_framework import authentication, exceptions
from .models import UserProfile

log = logging.getLogger(__name__)
_firebase_ready = None


def _init_firebase():
    global _firebase_ready
    if _firebase_ready is not None:
        return _firebase_ready
    try:
        import firebase_admin
        from firebase_admin import credentials
        if not firebase_admin._apps:
            cred = (credentials.Certificate(settings.FIREBASE_CREDENTIALS)
                    if settings.FIREBASE_CREDENTIALS else credentials.ApplicationDefault())
            firebase_admin.initialize_app(cred)
        _firebase_ready = True
    except Exception as exc:  # noqa: BLE001
        log.warning("Firebase Admin not initialised: %s", exc)
        _firebase_ready = False
    return _firebase_ready


class FirebaseAuthentication(authentication.BaseAuthentication):
    def authenticate_header(self, request):
        return "Bearer"  # makes DRF answer 401 (not 403) so clients can trigger re-login

    def authenticate(self, request):
        header = authentication.get_authorization_header(request).decode("utf-8")
        if not header:
            return None
        scheme, _, token = header.partition(" ")
        scheme = scheme.lower()

        if scheme == "dev":
            if not settings.DEV_AUTH:
                raise exceptions.AuthenticationFailed("Dev auth disabled")
            uid = token.strip() or "dev-user"
            user, _ = UserProfile.objects.get_or_create(
                firebase_uid=f"dev:{uid}", defaults={"email": f"{uid}@dev.local", "display_name": uid})
            return (user, None)

        if scheme != "bearer" or not token:
            raise exceptions.AuthenticationFailed("Invalid Authorization header")
        if not _init_firebase():
            raise exceptions.AuthenticationFailed("Auth service unavailable")
        from firebase_admin import auth as fb_auth
        try:
            decoded = fb_auth.verify_id_token(token, check_revoked=False)
        except Exception as exc:  # noqa: BLE001
            raise exceptions.AuthenticationFailed("Invalid or expired token") from exc
        user, _ = UserProfile.objects.get_or_create(
            firebase_uid=decoded["uid"],
            defaults={"email": decoded.get("email", ""), "display_name": decoded.get("name", "")})
        return (user, decoded)
