from rest_framework import serializers
from .models import UserProfile


class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProfile
        fields = ["id", "email", "display_name", "gender_pref", "style_tags", "favorite_colors",
                  "disliked_colors", "city", "latitude", "longitude", "onboarded", "created_at"]
        read_only_fields = ["id", "email", "created_at"]
