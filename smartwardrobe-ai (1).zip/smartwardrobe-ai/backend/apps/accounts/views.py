from rest_framework.response import Response
from rest_framework.views import APIView
from .serializers import UserProfileSerializer


class MeView(APIView):
    def get(self, request):
        return Response(UserProfileSerializer(request.user).data)

    def patch(self, request):
        ser = UserProfileSerializer(request.user, data=request.data, partial=True)
        ser.is_valid(raise_exception=True)
        ser.save()
        return Response(ser.data)

    def delete(self, request):
        """Account deletion (privacy requirement): removes profile and all owned data."""
        request.user.delete()
        return Response(status=204)
