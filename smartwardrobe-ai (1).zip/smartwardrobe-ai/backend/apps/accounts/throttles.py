from rest_framework.throttling import UserRateThrottle


class AIThrottle(UserRateThrottle):
    """Stricter limit for expensive AI endpoints (see DEFAULT_THROTTLE_RATES['ai'])."""
    scope = "ai"
