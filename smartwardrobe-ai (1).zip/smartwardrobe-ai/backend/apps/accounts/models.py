from django.db import models


class UserProfile(models.Model):
    """App user keyed by Firebase UID (no passwords stored here)."""
    firebase_uid = models.CharField(max_length=128, unique=True, db_index=True)
    email = models.EmailField(blank=True)
    display_name = models.CharField(max_length=120, blank=True)
    gender_pref = models.CharField(max_length=20, blank=True)  # menswear / womenswear / neutral
    style_tags = models.JSONField(default=list, blank=True)    # ["casual", "streetwear"]
    favorite_colors = models.JSONField(default=list, blank=True)
    disliked_colors = models.JSONField(default=list, blank=True)
    city = models.CharField(max_length=80, blank=True)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    onboarded = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    # DRF's IsAuthenticated checks this attribute on request.user.
    is_authenticated = True

    def __str__(self):
        return self.email or self.firebase_uid
