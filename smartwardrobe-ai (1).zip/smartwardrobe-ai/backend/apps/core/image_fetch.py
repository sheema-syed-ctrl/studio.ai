"""Safe image fetching (SSRF-guarded) and validation."""
import io
from urllib.parse import urlparse

import requests
from django.conf import settings
from PIL import Image


class ImageError(ValueError):
    pass


def fetch_image_url(url):
    p = urlparse(url)
    if p.scheme != "https" or (p.hostname or "") not in settings.ALLOWED_IMAGE_HOSTS:
        raise ImageError("image_url must be an https URL on an allowed storage host")
    try:
        r = requests.get(url, stream=True, timeout=10, allow_redirects=False)
    except requests.RequestException:
        raise ImageError("Could not download image")
    if r.status_code != 200:
        raise ImageError("Could not download image")
    data = b""
    for chunk in r.iter_content(65536):
        data += chunk
        if len(data) > settings.MAX_IMAGE_BYTES:
            raise ImageError("Image too large")
    return data


def open_image(data):
    if len(data) > settings.MAX_IMAGE_BYTES:
        raise ImageError("Image too large")
    try:
        img = Image.open(io.BytesIO(data))
        img.verify()
        img = Image.open(io.BytesIO(data))
        img.load()
    except Exception:
        raise ImageError("Not a valid image")
    if img.width * img.height > 40_000_000:
        raise ImageError("Image dimensions too large")
    return img
