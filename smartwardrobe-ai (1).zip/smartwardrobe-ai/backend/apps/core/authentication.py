"""Firebase ID-token authentication for DRF."""
import os

from django.conf import settings
from django.contrib.auth import get_user_model
from rest_framework.authentication import BaseAuthentication
from rest_framework.exceptions import AuthenticationFailed

_firebase_ready = False


def _init_firebase():
    global _firebase_ready
    if _firebase_ready:
        return
    import firebase_admin
    from firebase_admin import credentials

    if not firebase_admin._apps:
        path = settings.FIREBASE_CREDENTIALS or os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
        cred = credentials.Certificate(path) if path else credentials.ApplicationDefault()
        firebase_admin.initialize_app(cred)
    _firebase_ready = True


def verify_firebase_token(token):
    _init_firebase()
    from firebase_admin import auth

    try:
        return auth.verify_id_token(token)
    except Exception:
        raise AuthenticationFailed("Invalid or expired token")


class FirebaseAuthentication(BaseAuthentication):
    def authenticate(self, request):
        header = request.headers.get("Authorization", "")
        if not header.startswith("Bearer "):
            return None
        token = header[7:].strip()
        if settings.DEV_AUTH_BYPASS and token.startswith("dev:"):
            uid = token[4:][:60] or "demo"
            claims = {"uid": uid, "email": f"{uid}@dev.local", "name": uid.title()}
        else:
            claims = verify_firebase_token(token)
        uid = claims["uid"]
        User = get_user_model()
        user, created = User.objects.get_or_create(username=uid, defaults={"email": claims.get("email", "")})
        if created:
            user.set_unusable_password()
            user.save(update_fields=["password"])
        from apps.accounts.models import UserProfile

        UserProfile.objects.get_or_create(user=user, defaults={"display_name": claims.get("name", "")})
        return (user, claims)

    def authenticate_header(self, request):
        return "Bearer"
