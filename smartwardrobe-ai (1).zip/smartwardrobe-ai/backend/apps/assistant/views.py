from rest_framework import serializers
from rest_framework.response import Response
from rest_framework.throttling import UserRateThrottle
from rest_framework.views import APIView

from .service import reply


class ChatThrottle(UserRateThrottle):
    scope = "chat"


class ChatRequest(serializers.Serializer):
    message = serializers.CharField(max_length=500)
    history = serializers.ListField(child=serializers.DictField(), required=False, max_length=12, default=list)


class ChatView(APIView):
    throttle_classes = [ChatThrottle]

    def post(self, request):
        s = ChatRequest(data=request.data)
        s.is_valid(raise_exception=True)
        return Response({"reply": reply(request.user, s.validated_data["message"], s.validated_data["history"])})
