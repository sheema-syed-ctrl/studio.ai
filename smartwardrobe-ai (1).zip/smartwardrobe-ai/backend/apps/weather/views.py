from rest_framework import serializers
from rest_framework.response import Response
from rest_framework.views import APIView

from .service import resolve_weather


class WeatherQuery(serializers.Serializer):
    lat = serializers.FloatField(min_value=-90, max_value=90)
    lon = serializers.FloatField(min_value=-180, max_value=180)


class WeatherView(APIView):
    def get(self, request):
        q = WeatherQuery(data=request.query_params)
        q.is_valid(raise_exception=True)
        return Response(resolve_weather(lat=q.validated_data["lat"], lon=q.validated_data["lon"]))
