"""Weather via Open-Meteo (no API key). Results cached 30 min per ~1km cell."""
import requests
from django.core.cache import cache

LABEL_TEMP = {"hot": 34, "warm": 27, "mild": 21, "cool": 15, "cold": 6}
LABELS = list(LABEL_TEMP)


def label_for_temp(t):
    if t >= 30:
        return "hot"
    if t >= 24:
        return "warm"
    if t >= 18:
        return "mild"
    if t >= 12:
        return "cool"
    return "cold"


def fetch_weather(lat, lon):
    key = f"wx:{round(lat, 2)}:{round(lon, 2)}"
    hit = cache.get(key)
    if hit:
        return hit
    try:
        r = requests.get("https://api.open-meteo.com/v1/forecast", timeout=8, params={
            "latitude": lat, "longitude": lon, "current": "temperature_2m,precipitation,weather_code"})
        r.raise_for_status()
        cur = r.json()["current"]
    except Exception:
        return None
    temp = float(cur["temperature_2m"])
    raining = float(cur.get("precipitation", 0)) > 0.1 or int(cur.get("weather_code", 0)) in range(51, 100)
    data = {"temp_c": temp, "label": label_for_temp(temp), "is_raining": raining, "source": "open-meteo"}
    cache.set(key, data, 1800)
    return data


def resolve_weather(label=None, temp_c=None, lat=None, lon=None, rainy=None):
    """Priority: explicit label > explicit temp > live lookup > mild default."""
    if label in ("rainy", "rain"):
        return {"temp_c": 21.0, "label": "mild", "is_raining": True, "source": "manual"}
    if label in LABEL_TEMP:
        return {"temp_c": float(LABEL_TEMP[label]), "label": label, "is_raining": bool(rainy), "source": "manual"}
    if temp_c is not None:
        return {"temp_c": float(temp_c), "label": label_for_temp(temp_c), "is_raining": bool(rainy), "source": "manual"}
    if lat is not None and lon is not None:
        live = fetch_weather(lat, lon)
        if live:
            return live
    return {"temp_c": 21.0, "label": "mild", "is_raining": False, "source": "default"}
