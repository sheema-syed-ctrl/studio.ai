"""Transparent outfit scoring engine. Only recommends items the user owns.

Pipeline: filter by weather/occasion -> build candidate combos -> score -> explain.
Score = weighted sum of: color harmony, formality fit, weather fit, style match,
freshness (not worn recently), favourites, and learned preference from feedback.
"""
import itertools
from datetime import date
from services.ai.color import outfit_color_score

OCCASION_FORMALITY = {"college": (2, 3), "casual": (1, 3), "work": (3, 5), "formal": (4, 5),
                      "party": (3, 5), "date": (3, 4), "gym": (1, 2), "travel": (1, 3), "wedding": (4, 5)}
BAND_WARMTH = {"hot": (1, 1), "warm": (1, 2), "cool": (2, 3), "cold": (3, 4)}
W = dict(color=0.26, formality=0.22, weather=0.20, style=0.08, fresh=0.10, fav=0.04, pref=0.10)
MAX_POOL = 12  # per category, keeps combinatorics small


def _in_range(v, lo, hi):
    return 1.0 if lo <= v <= hi else max(0.0, 1 - 0.4 * min(abs(v - lo), abs(v - hi)))


def _eligible(items, occasion, band):
    lo, hi = OCCASION_FORMALITY.get(occasion, (1, 5))
    out = []
    for it in items:
        if it.is_archived:
            continue
        if it.occasions and occasion not in it.occasions and _in_range(it.formality, lo, hi) < 0.6:
            continue
        out.append(it)
    return out


def _ranked(pool, occasion, band, limit=MAX_POOL):
    lo, hi = OCCASION_FORMALITY.get(occasion, (1, 5))
    wlo, whi = BAND_WARMTH.get(band, (1, 4))
    key = lambda i: -(_in_range(i.formality, lo, hi) + _in_range(i.warmth, wlo, whi) + (0.3 if i.is_favorite else 0))  # noqa: E731
    return sorted(pool, key=key)[:limit]


def _freshness(items):
    today, vals = date.today(), []
    for it in items:
        vals.append(1.0 if not it.last_worn else min(1.0, (today - it.last_worn).days / 7))
    return sum(vals) / len(vals)


def score_outfit(items, occasion, weather, profile, disliked_ids=frozenset(), liked_ids=frozenset()):
    lo, hi = OCCASION_FORMALITY.get(occasion, (1, 5))
    wlo, whi = BAND_WARMTH.get(weather["band"], (1, 4))
    colors = [i.primary_color for i in items if i.primary_color]
    fam = outfit_color_score(colors)
    if profile is not None:
        liked = set(profile.favorite_colors or []); bad = set(profile.disliked_colors or [])
        fam = min(1.0, fam + 0.05 * len(liked & set(colors))) - 0.15 * len(bad & set(colors))
    form = sum(_in_range(i.formality, lo, hi) for i in items) / len(items)
    # Warmth is judged on the whole outfit: layers add up
    total_warmth = sum(i.warmth for i in items if i.category in ("top", "bottom", "outerwear")) / 2.0
    wx = _in_range(total_warmth, wlo, whi)
    if weather.get("rain") and any(i.subcategory in ("sandals", "loafers", "canvas") for i in items):
        wx -= 0.25
    style_tags = set((profile.style_tags if profile else []) or [])
    style = 0.6
    if style_tags:
        item_tags = {t for i in items for t in (i.occasions or [])}
        style = 0.5 + 0.5 * bool(style_tags & item_tags)
    fav = sum(i.is_favorite for i in items) / len(items)
    ids = {i.id for i in items}
    pref = 0.5 + 0.5 * (len(ids & liked_ids) / len(ids)) - 0.5 * (len(ids & disliked_ids) / len(ids))
    parts = dict(color=fam, formality=form, weather=max(0, wx), style=style,
                 fresh=_freshness(items), fav=fav, pref=max(0, min(1, pref)))
    return sum(W[k] * parts[k] for k in W), parts


def explain(items, occasion, weather, parts):
    reasons = [f"fits a {occasion} occasion"] if parts["formality"] >= 0.8 else []
    reasons.append(f"suits {weather['band']} weather ({weather['temp_c']}°C)" if parts["weather"] >= 0.8 else "weather fit is approximate")
    if parts["color"] >= 0.75:
        reasons.append("colors pair well")
    if parts["fresh"] >= 0.9:
        reasons.append("includes pieces you haven't worn recently")
    return ", ".join(reasons).capitalize() + "."


def recommend(user, occasion, weather, count=3, exclude_ids=frozenset(), feedback=None):
    from apps.wardrobe.models import ClothingItem
    occasion = (occasion or "casual").lower()
    items = [i for i in ClothingItem.objects.filter(user=user, is_archived=False)]
    by_cat = {c: _ranked(_eligible([i for i in items if i.category == c], occasion, weather["band"]),
                         occasion, weather["band"]) for c in ("top", "bottom", "footwear", "outerwear", "accessory")}
    missing = [c for c in ("top", "bottom", "footwear") if not by_cat[c]]
    if missing:
        return {"outfits": [], "missing": missing,
                "message": f"Add at least one {', '.join(missing)} to get recommendations."}
    liked_ids = frozenset((feedback or {}).get("liked", ()))
    disliked_ids = frozenset((feedback or {}).get("disliked", ()))
    disliked_combos = (feedback or {}).get("disliked_combos", set())
    layer_options = [None]
    if weather["band"] in ("cool", "cold") or weather.get("rain"):
        layer_options = by_cat["outerwear"][:4] or [None]
    results = []
    for top, bottom, shoe, layer in itertools.product(by_cat["top"], by_cat["bottom"], by_cat["footwear"], layer_options):
        combo = [x for x in (top, bottom, shoe, layer) if x]
        key = tuple(sorted(i.id for i in combo))
        if key in exclude_ids or key in disliked_combos:
            continue
        s, parts = score_outfit(combo, occasion, weather, user, disliked_ids, liked_ids)
        results.append((s, combo, parts))
    results.sort(key=lambda r: -r[0])
    picked, used_tops = [], {}
    for s, combo, parts in results:  # diversity: avoid the same top in every suggestion
        top_id = combo[0].id
        if used_tops.get(top_id, 0) >= 1 and len(picked) < count and len(results) > count * 3:
            continue
        used_tops[top_id] = used_tops.get(top_id, 0) + 1
        picked.append({"score": round(s, 3), "items": combo, "explanation": explain(combo, occasion, weather, parts),
                       "breakdown": {k: round(v, 2) for k, v in parts.items()}})
        if len(picked) == count:
            break
    return {"outfits": picked, "missing": [], "message": ""}
