"""Weather adapter. Returns a normalised snapshot; falls back to a labelled mock."""
import requests
from django.conf import settings

BANDS = [(12, "cold"), (21, "cool"), (28, "warm"), (99, "hot")]


def band(temp_c):
    return next(name for limit, name in BANDS if temp_c < limit)


def snapshot(temp_c, rain=False, source="manual"):
    return {"temp_c": round(temp_c, 1), "band": band(temp_c), "rain": rain, "source": source}


def from_band(name):
    """User-picked weather (e.g. 'Hot' in the UI) => representative snapshot."""
    mid = {"cold": 6, "cool": 17, "warm": 25, "hot": 34, "rainy": 20}.get(name.lower(), 22)
    return snapshot(mid, rain=name.lower() == "rainy", source="manual")


def current(lat, lon):
    if not settings.OPENWEATHER_API_KEY or lat is None or lon is None:
        return {**snapshot(26, False, source="mock"), "note": "Set OPENWEATHER_API_KEY and location for live weather"}
    try:
        r = requests.get("https://api.openweathermap.org/data/2.5/weather", timeout=6,
                         params={"lat": lat, "lon": lon, "units": "metric", "appid": settings.OPENWEATHER_API_KEY})
        r.raise_for_status()
        d = r.json()
        rain = any(w.get("main", "").lower() in {"rain", "drizzle", "thunderstorm"} for w in d.get("weather", []))
        return {**snapshot(d["main"]["temp"], rain, source="openweather"), "description": d["weather"][0]["description"]}
    except Exception:  # noqa: BLE001
        return {**snapshot(26, False, source="mock"), "note": "Weather service unavailable"}
