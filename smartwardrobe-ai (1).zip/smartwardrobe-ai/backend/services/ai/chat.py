"""AI fashion chat. Uses Anthropic if configured; otherwise a rule-based stylist.
The wardrobe is passed as compact text so the model can only suggest owned pieces."""
import logging
import requests
from django.conf import settings

log = logging.getLogger(__name__)
SYSTEM = ("You are SmartWardrobe's stylist. Only suggest clothes from the user's wardrobe list. "
          "Be concise (max 120 words). If the wardrobe lacks something, say what is missing instead of inventing items.")


def wardrobe_text(user):
    from apps.wardrobe.models import ClothingItem
    rows = ClothingItem.objects.filter(user=user, is_archived=False)[:80]
    return "\n".join(f"- #{i.id} {i.display_name} ({i.category}, formality {i.formality}, warmth {i.warmth})" for i in rows) or "(empty wardrobe)"


def reply(user, message, history, weather):
    if settings.ANTHROPIC_API_KEY:
        try:
            msgs = [{"role": h["role"], "content": str(h["content"])[:600]} for h in history[-8:]
                    if isinstance(h, dict) and h.get("role") in ("user", "assistant")]
            msgs.append({"role": "user", "content": message})
            r = requests.post("https://api.anthropic.com/v1/messages", timeout=25, headers={
                "x-api-key": settings.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01"}, json={
                "model": settings.ANTHROPIC_MODEL, "max_tokens": 400,
                "system": f"{SYSTEM}\nWeather: {weather['temp_c']}°C, rain={weather['rain']}\nWardrobe:\n{wardrobe_text(user)}",
                "messages": msgs})
            r.raise_for_status()
            return "".join(b.get("text", "") for b in r.json()["content"]), "llm"
        except Exception as exc:  # noqa: BLE001
            log.warning("LLM chat failed, using fallback: %s", exc)
    from services.recommender import recommend
    text = message.lower()
    occ = next((o for o in ("college", "work", "formal", "party", "date", "gym", "wedding", "travel") if o in text), "casual")
    rec = recommend(user, occ, weather, count=1)
    if rec["message"]:
        return rec["message"], "rules"
    o = rec["outfits"][0]
    names = ", ".join(i.display_name for i in o["items"])
    return f"For {occ} today ({weather['temp_c']}°C), try: {names}. {o['explanation']}", "rules"
