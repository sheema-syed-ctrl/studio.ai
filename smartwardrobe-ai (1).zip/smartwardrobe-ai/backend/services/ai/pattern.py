import numpy as np


def detect_pattern(img, n_secondary):
    """Heuristic: solid / striped / printed from luminance gradients."""
    g = np.asarray(img.convert("L").resize((64, 64)), dtype=np.float32)[8:-8, 8:-8]
    dx = np.abs(np.diff(g, axis=1)).mean()
    dy = np.abs(np.diff(g, axis=0)).mean()
    energy = (dx + dy) / 2
    if n_secondary == 0 and energy < 6:
        return "solid"
    ratio = (dx + 1e-3) / (dy + 1e-3)
    if energy > 8 and (ratio > 2.0 or ratio < 0.5):
        return "striped"
    if n_secondary >= 1 and energy > 8:
        return "printed"
    return "solid"
