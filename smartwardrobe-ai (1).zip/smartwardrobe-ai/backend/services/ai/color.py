"""Color extraction, naming and compatibility (pure numpy/colorsys, no heavy deps)."""
import colorsys
import numpy as np

NAMED = {
    "white": (245, 245, 245), "black": (20, 20, 20), "grey": (128, 128, 128),
    "navy": (25, 35, 90), "blue": (40, 90, 200), "light blue": (150, 190, 235),
    "red": (200, 40, 40), "maroon": (110, 20, 40), "pink": (240, 150, 180),
    "orange": (240, 140, 40), "yellow": (240, 210, 60), "green": (50, 150, 70),
    "olive": (110, 120, 50), "teal": (30, 130, 130), "purple": (120, 60, 160),
    "brown": (110, 70, 40), "beige": (225, 205, 170), "cream": (250, 244, 225),
    "khaki": (190, 175, 120),
}
NEUTRALS = {"white", "black", "grey", "beige", "cream", "navy", "khaki", "brown", "denim"}
WARM = {"red", "orange", "yellow", "maroon", "brown", "beige", "khaki", "pink", "cream"}
COOL = {"blue", "light blue", "navy", "green", "teal", "purple", "olive"}


def rgb_to_name(rgb):
    r, g, b = rgb
    h, l, s = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
    # Low saturation => achromatic family decided by lightness
    if s < 0.12 or l > 0.93 or l < 0.08:
        return "white" if l > 0.8 else "black" if l < 0.18 else "grey"
    best, dist = "grey", 1e9
    for name, c in NAMED.items():
        d = sum((a - b2) ** 2 for a, b2 in zip(rgb, c))
        if d < dist:
            best, dist = name, d
    return best


def dominant_colors(pixels, k=3, iters=12, seed=0):
    """K-means on an (N,3) uint8 array. Returns [(name, share)] sorted by share."""
    px = np.asarray(pixels, dtype=np.float32).reshape(-1, 3)
    if len(px) == 0:
        return []
    rng = np.random.default_rng(seed)
    k = min(k, len(px))
    centers = px[rng.choice(len(px), k, replace=False)]
    for _ in range(iters):
        labels = np.argmin(((px[:, None, :] - centers[None]) ** 2).sum(-1), axis=1)
        for i in range(k):
            members = px[labels == i]
            if len(members):
                centers[i] = members.mean(0)
    counts = np.bincount(labels, minlength=k) / len(px)
    merged = {}
    for c, share in zip(centers, counts):
        name = rgb_to_name(tuple(int(v) for v in c))
        merged[name] = merged.get(name, 0) + float(share)
    return sorted(merged.items(), key=lambda t: -t[1])


def compatibility(c1, c2):
    """0..1 score for how well two named colors pair."""
    if c1 == c2:
        return 0.75 if c1 in NEUTRALS else 0.55
    n1, n2 = c1 in NEUTRALS, c2 in NEUTRALS
    if n1 and n2:
        if {c1, c2} == {"black", "navy"} or {c1, c2} == {"brown", "black"}:
            return 0.45
        return 0.9
    if n1 or n2:
        return 0.85
    if (c1 in WARM) != (c2 in WARM) and (c1 in COOL or c2 in COOL):
        return 0.5 if {c1, c2} & {"red", "orange"} and {c1, c2} & {"pink"} else 0.6
    if (c1 in WARM) == (c2 in WARM):
        return 0.65
    return 0.4


def outfit_color_score(colors):
    """Average pairwise compatibility, penalising >2 loud (non-neutral) colors."""
    if len(colors) < 2:
        return 0.7
    pairs = [(a, b) for i, a in enumerate(colors) for b in colors[i + 1:]]
    score = sum(compatibility(a, b) for a, b in pairs) / len(pairs)
    loud = sum(1 for c in colors if c not in NEUTRALS)
    return max(0.0, score - 0.12 * max(0, loud - 2))
