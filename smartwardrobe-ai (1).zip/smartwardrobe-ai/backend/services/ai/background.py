import io


def remove_background(img):
    """Returns PNG bytes with background removed, or None if rembg is not installed."""
    try:
        from rembg import remove
    except ImportError:
        return None
    out = remove(img.convert("RGB"))
    buf = io.BytesIO()
    out.save(buf, format="PNG")
    return buf.getvalue()
