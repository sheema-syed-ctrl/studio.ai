import base64

from .background import remove_background
from .classifier import classify
from .color import analyze_colors
from .pattern import detect_pattern
from .taxonomy import TAXONOMY

LOW_CONFIDENCE = 0.45


def analyze_image(img, remove_bg=False):
    """Image -> suggested clothing metadata. The user confirms/edits it in the app."""
    cutout_b64 = None
    if remove_bg:
        png = remove_background(img)
        if png:
            cutout_b64 = base64.b64encode(png).decode()
    sub, conf = classify(img)
    category, warmth, formality = TAXONOMY[sub]
    colors = analyze_colors(img)
    pattern = detect_pattern(img, len(colors["secondary_colors"]))
    return {
        "category": category, "subcategory": sub, "warmth": warmth, "formality": formality,
        "pattern": pattern, **colors,
        "confidence": round(conf, 3), "needs_review": conf < LOW_CONFIDENCE,
        "cutout_base64": cutout_b64,
    }
