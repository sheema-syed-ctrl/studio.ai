"""Clothing type classification: CLIP zero-shot when installed, honest heuristic fallback otherwise."""
from django.conf import settings

from .taxonomy import TAXONOMY

_clip = None


def _clip_classify(img):
    global _clip
    import torch
    from transformers import CLIPModel, CLIPProcessor

    if _clip is None:
        name = "openai/clip-vit-base-patch32"
        _clip = (CLIPModel.from_pretrained(name).eval(), CLIPProcessor.from_pretrained(name))
    model, proc = _clip
    labels = list(TAXONOMY)
    inputs = proc(text=[f"a photo of a {l}, a piece of clothing" for l in labels], images=img.convert("RGB"),
                  return_tensors="pt", padding=True)
    with torch.no_grad():
        probs = model(**inputs).logits_per_image.softmax(dim=1)[0]
    i = int(probs.argmax())
    return labels[i], float(probs[i])


def _heuristic(img):
    ratio = img.width / img.height
    if ratio > 1.35:
        return "sneakers", 0.2
    if ratio < 0.75:
        return "jeans", 0.2
    return "t-shirt", 0.2


def classify(img):
    """Returns (subcategory, confidence)."""
    if settings.AI_CLASSIFIER == "clip":
        try:
            return _clip_classify(img)
        except ImportError:
            pass
    return _heuristic(img)
