"""Clothing image analysis: color, pattern, category, optional background removal.

Heavy models (CLIP, rembg) are optional. Without them the analyzer still returns
colors + pattern and marks category as 'unknown' so the app asks the user to confirm.
Every result carries `confidence` and `source` so the UI can show "AI suggested".
"""
import io, ipaddress, logging, socket
from urllib.parse import urlparse
import numpy as np
import requests
from PIL import Image
from .color import dominant_colors

log = logging.getLogger(__name__)
CATEGORIES = {
    "top": ["t-shirt", "shirt", "polo", "hoodie", "sweater", "kurta", "top", "blouse"],
    "bottom": ["jeans", "trousers", "shorts", "skirt", "joggers", "leggings"],
    "outerwear": ["jacket", "blazer", "coat", "cardigan"],
    "footwear": ["sneakers", "formal shoes", "sandals", "boots", "loafers"],
    "accessory": ["cap", "watch", "belt", "scarf", "bag", "sunglasses"],
}
SUBTYPE_TO_CATEGORY = {s: c for c, subs in CATEGORIES.items() for s in subs}
FORMAL = {"blazer", "formal shoes", "loafers", "trousers", "shirt", "blouse", "belt"}
SPORTY = {"joggers", "leggings", "sneakers", "hoodie", "cap", "shorts", "t-shirt"}
MAX_BYTES = 10 * 1024 * 1024


class UnsafeURL(ValueError):
    pass


def _assert_public_url(url):
    p = urlparse(url)
    if p.scheme != "https" or not p.hostname:
        raise UnsafeURL("Only https image URLs are allowed")
    for info in socket.getaddrinfo(p.hostname, 443):
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            raise UnsafeURL("URL resolves to a non-public address")


def load_image(source):
    """source: file-like/bytes or https URL. SSRF-guarded, size-limited."""
    if isinstance(source, str):
        _assert_public_url(source)
        r = requests.get(source, timeout=10, stream=True, allow_redirects=False)
        r.raise_for_status()
        data = r.raw.read(MAX_BYTES + 1, decode_content=True)
        if len(data) > MAX_BYTES:
            raise ValueError("Image too large")
    else:
        data = source if isinstance(source, bytes) else source.read()
    img = Image.open(io.BytesIO(data))
    img.load()
    return img


def _foreground_pixels(img):
    """Centre-weighted pixel sample, ignoring near-uniform background and transparent pixels."""
    rgba = img.convert("RGBA").resize((96, 96))
    arr = np.asarray(rgba)
    rgb, alpha = arr[..., :3].reshape(-1, 3), arr[..., 3].reshape(-1)
    keep = alpha > 200
    if keep.all():  # no transparency: drop border-coloured pixels (studio backdrop)
        border = np.concatenate([arr[0, :, :3], arr[-1, :, :3], arr[:, 0, :3], arr[:, -1, :3]]).mean(0)
        far = np.linalg.norm(rgb.astype(float) - border, axis=1) > 38
        if far.mean() > 0.15:
            keep = far
    return rgb[keep] if keep.sum() > 50 else rgb


def detect_pattern(img):
    """Cheap heuristic: solid / striped / checked / printed from gradient energy + periodicity."""
    g = np.asarray(img.convert("L").resize((96, 96)), dtype=np.float32)
    inner = g[16:-16, 16:-16]
    if inner.std() < 10:
        return "solid"
    gx, gy = np.abs(np.diff(inner, axis=1)).mean(), np.abs(np.diff(inner, axis=0)).mean()
    ratio = max(gx, gy) / (min(gx, gy) + 1e-3)
    if max(gx, gy) < 6:
        return "solid"
    if ratio > 2.2:
        return "striped"
    if inner.std() > 45 and 0.7 < ratio < 1.4 and max(gx, gy) > 14:
        return "checked"
    return "printed" if max(gx, gy) > 12 else "textured"


_clip = None


def classify_category(img):
    """CLIP zero-shot if transformers+torch present; else unknown."""
    global _clip
    try:
        if _clip is None:
            from transformers import CLIPModel, CLIPProcessor
            _clip = (CLIPModel.from_pretrained("openai/clip-vit-base-patch32"),
                     CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32"))
        import torch
        model, proc = _clip
        labels = list(SUBTYPE_TO_CATEGORY)
        inputs = proc(text=[f"a photo of a {l}" for l in labels], images=img.convert("RGB"),
                      return_tensors="pt", padding=True)
        with torch.no_grad():
            probs = model(**inputs).logits_per_image.softmax(1)[0]
        i = int(probs.argmax())
        return labels[i], SUBTYPE_TO_CATEGORY[labels[i]], float(probs[i])
    except Exception as exc:  # noqa: BLE001
        log.info("Classifier unavailable (%s); category left for user confirmation", exc)
        return "", "unknown", 0.0


def remove_background(img):
    try:
        from rembg import remove
        return remove(img.convert("RGBA"))
    except Exception:  # noqa: BLE001
        return None


def infer_attributes(subtype, colors):
    formality = 4 if subtype in FORMAL else 2 if subtype in SPORTY else 3
    seasons = ["summer"] if subtype in {"shorts", "sandals", "t-shirt", "skirt"} else \
              ["winter", "autumn"] if subtype in {"hoodie", "sweater", "coat", "jacket", "boots", "cardigan"} else \
              ["spring", "summer", "autumn", "winter"]
    warmth = 1 if "summer" in seasons and len(seasons) == 1 else 4 if "winter" in seasons and len(seasons) == 2 else 2
    occasions = ["formal", "work", "party"] if formality >= 4 else \
                ["gym", "casual", "college"] if formality <= 2 else ["casual", "college", "party", "date"]
    return {"formality": formality, "seasons": seasons, "warmth": warmth, "occasions": occasions}


def analyze(source, remove_bg=False):
    img = load_image(source)
    colors = dominant_colors(_foreground_pixels(img), k=3)
    subtype, category, conf = classify_category(img)
    out = {
        "primary_color": colors[0][0] if colors else "grey",
        "secondary_colors": [c for c, s in colors[1:] if s > 0.15],
        "pattern": detect_pattern(img),
        "subcategory": subtype, "category": category, "confidence": round(conf, 3),
        "source": "clip" if conf else "heuristic",
    }
    out.update(infer_attributes(subtype, colors))
    if remove_bg:
        cut = remove_background(img)
        if cut is not None:
            buf = io.BytesIO(); cut.save(buf, "PNG"); out["cutout_png"] = buf.getvalue()
    return out
