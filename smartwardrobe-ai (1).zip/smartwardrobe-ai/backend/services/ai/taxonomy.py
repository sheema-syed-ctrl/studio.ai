"""Clothing taxonomy: subcategory -> (category, warmth 1-5, formality 1-5)."""
TAXONOMY = {
    "t-shirt": ("top", 1, 1), "tank top": ("top", 1, 1), "polo": ("top", 1, 2),
    "shirt": ("top", 1, 3), "blouse": ("top", 1, 3), "kurta": ("top", 2, 3),
    "sweater": ("top", 4, 2), "hoodie": ("top", 4, 1), "sweatshirt": ("top", 3, 1),
    "jeans": ("bottom", 2, 2), "trousers": ("bottom", 2, 4), "chinos": ("bottom", 2, 3),
    "shorts": ("bottom", 1, 1), "joggers": ("bottom", 2, 1), "skirt": ("bottom", 1, 3),
    "leggings": ("bottom", 2, 1), "palazzo": ("bottom", 1, 2),
    "dress": ("dress", 2, 3), "ethnic dress": ("dress", 2, 4),
    "jacket": ("outerwear", 4, 2), "blazer": ("outerwear", 3, 4), "coat": ("outerwear", 5, 4),
    "raincoat": ("outerwear", 3, 2), "cardigan": ("outerwear", 3, 2),
    "sneakers": ("footwear", 2, 1), "formal shoes": ("footwear", 2, 5), "loafers": ("footwear", 2, 4),
    "sandals": ("footwear", 1, 1), "boots": ("footwear", 4, 3), "heels": ("footwear", 2, 4),
    "watch": ("accessory", 1, 3), "belt": ("accessory", 1, 3), "cap": ("accessory", 1, 1),
    "scarf": ("accessory", 3, 2), "sunglasses": ("accessory", 1, 2),
}
OPEN_FOOTWEAR = {"sandals", "heels"}
CATEGORIES = ["top", "bottom", "dress", "outerwear", "footwear", "accessory"]


def defaults_for(subcategory):
    return TAXONOMY.get((subcategory or "").lower())
