import io
from PIL import Image
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from rest_framework.test import APIClient
from apps.accounts.models import UserProfile
from apps.wardrobe.models import ClothingItem
from services.ai import analyzer
from services.ai.color import compatibility, outfit_color_score


def png(color=(250, 250, 250), size=(64, 64)):
    buf = io.BytesIO(); Image.new("RGB", size, color).save(buf, "PNG")
    return SimpleUploadedFile("x.png", buf.getvalue(), content_type="image/png")


@override_settings(DEV_AUTH=True, MEDIA_ROOT="/tmp/sw_test_media")
class ApiTests(TestCase):
    def client_for(self, uid):
        c = APIClient(); c.credentials(HTTP_AUTHORIZATION=f"Dev {uid}"); return c

    def setUp(self):
        self.a, self.b = self.client_for("alice"), self.client_for("bob")
        self.alice = None

    def add(self, c, **kw):
        base = dict(analyze=False, name="x", image_url="https://firebasestorage.googleapis.com/v0/b/x/o/y.png")
        base.update(kw)
        r = c.post("/api/wardrobe/items/", base, format="json")
        self.assertEqual(r.status_code, 201, r.content)
        return r.json()

    def test_requires_auth(self):
        self.assertEqual(APIClient().get("/api/wardrobe/items/").status_code, 401)

    def test_dev_auth_disabled_when_off(self):
        with override_settings(DEV_AUTH=False):
            self.assertEqual(self.a.get("/api/me/").status_code, 401)

    def test_upload_runs_analysis(self):
        r = self.a.post("/api/wardrobe/items/", {"image": png((250, 250, 250))}, format="multipart")
        self.assertEqual(r.status_code, 201, r.content)
        self.assertEqual(r.json()["primary_color"], "white")
        self.assertEqual(r.json()["pattern"], "solid")

    def test_user_values_not_overwritten_by_ai(self):
        r = self.a.post("/api/wardrobe/items/", {"image": png((250, 250, 250)), "primary_color": "cream"}, format="multipart")
        self.assertEqual(r.json()["primary_color"], "cream")

    def test_rejects_untrusted_image_url(self):
        r = self.a.post("/api/wardrobe/items/", {"image_url": "https://evil.example.com/a.png", "analyze": False}, format="json")
        self.assertEqual(r.status_code, 400)
        r = self.a.post("/api/wardrobe/items/", {"image_url": "http://firebasestorage.googleapis.com/a.png"}, format="json")
        self.assertEqual(r.status_code, 400)

    def test_requires_image(self):
        self.assertEqual(self.a.post("/api/wardrobe/items/", {"name": "x"}, format="json").status_code, 400)

    def test_user_isolation(self):
        item = self.add(self.a, category="top")
        self.assertEqual(self.b.get(f"/api/wardrobe/items/{item['id']}/").status_code, 404)
        self.assertEqual(self.b.delete(f"/api/wardrobe/items/{item['id']}/").status_code, 404)
        self.assertEqual(self.b.get("/api/wardrobe/items/").json()["count"], 0)

    def test_cannot_build_outfit_from_other_users_items(self):
        item = self.add(self.a, category="top")
        r = self.b.post("/api/outfits/", {"item_ids": [item["id"]], "occasion": "casual"}, format="json")
        self.assertEqual(r.status_code, 400)

    def wardrobe(self, c):
        spec = [("top", "t-shirt", "white", 2, 1), ("top", "hoodie", "black", 2, 4), ("bottom", "jeans", "blue", 2, 2),
                ("bottom", "trousers", "black", 4, 2), ("footwear", "sneakers", "white", 2, 1),
                ("footwear", "formal shoes", "black", 5, 2), ("top", "shirt", "light blue", 4, 1)]
        return [self.add(c, category=cat, subcategory=sub, primary_color=col, formality=f, warmth=w,
                         occasions=["college", "casual"] if f <= 3 else ["work", "formal"])
                for cat, sub, col, f, w in spec]

    def test_recommendation_college_hot_casual_uses_owned_light_outfit(self):
        owned = self.wardrobe(self.a)
        r = self.a.post("/api/recommend/", {"occasion": "college", "weather": "hot", "style": "casual"}, format="json").json()
        self.assertTrue(r["outfits"])
        best = {i["subcategory"] for i in r["outfits"][0]["items"]}
        self.assertEqual(best, {"t-shirt", "jeans", "sneakers"})
        owned_ids = {o["id"] for o in owned}
        for o in r["outfits"]:
            self.assertTrue({i["id"] for i in o["items"]} <= owned_ids)
        self.assertEqual(r["weather"]["band"], "hot")

    def test_recommendation_other_users_wardrobe_never_leaks(self):
        self.wardrobe(self.a)
        r = self.b.post("/api/recommend/", {"occasion": "college", "weather": "hot"}, format="json").json()
        self.assertEqual(r["outfits"], [])
        self.assertEqual(sorted(r["missing"]), ["bottom", "footwear", "top"])

    def test_cold_weather_adds_layer_when_owned(self):
        self.wardrobe(self.a)
        self.add(self.a, category="outerwear", subcategory="jacket", primary_color="navy", formality=3, warmth=4, occasions=["casual", "college"])
        r = self.a.post("/api/recommend/", {"occasion": "casual", "weather": "cold"}, format="json").json()
        self.assertTrue(any(i["category"] == "outerwear" for i in r["outfits"][0]["items"]))

    def test_feedback_wear_and_analytics(self):
        self.wardrobe(self.a)
        r = self.a.post("/api/recommend/", {"occasion": "casual", "weather": "warm"}, format="json").json()
        oid = r["outfits"][0]["id"]
        self.assertEqual(self.a.post(f"/api/outfits/{oid}/feedback/", {"liked": True, "reason": "love it"}, format="json").status_code, 200)
        self.assertEqual(self.a.post(f"/api/outfits/{oid}/wear/").status_code, 200)
        self.a.post(f"/api/outfits/{oid}/wear/")  # idempotent per day
        stats = self.a.get("/api/analytics/").json()
        self.assertEqual(stats["outfits_worn"], 1)
        self.assertEqual(stats["like_rate"], 1.0)
        self.assertTrue(all(i["times_worn"] == 1 for i in stats["most_worn"]))
        self.assertEqual(self.b.post(f"/api/outfits/{oid}/wear/").status_code, 404)

    def test_disliked_outfit_is_deprioritised(self):
        self.wardrobe(self.a)
        first = self.a.post("/api/recommend/", {"occasion": "casual", "weather": "warm", "count": 1}, format="json").json()["outfits"][0]
        self.a.post(f"/api/outfits/{first['id']}/feedback/", {"liked": False, "reason": "no"}, format="json")
        again = self.a.post("/api/recommend/", {"occasion": "casual", "weather": "warm", "count": 1}, format="json").json()["outfits"][0]
        self.assertNotEqual({i["id"] for i in first["items"]}, {i["id"] for i in again["items"]})

    def test_chat_fallback_and_validation(self):
        self.wardrobe(self.a)
        self.assertEqual(self.a.post("/api/chat/", {"message": ""}, format="json").status_code, 400)
        r = self.a.post("/api/chat/", {"message": "What should I wear to college?"}, format="json").json()
        self.assertEqual(r["source"], "rules")

    def test_profile_update_and_delete_cascades(self):
        self.a.patch("/api/me/", {"style_tags": ["casual"], "favorite_colors": ["blue"]}, format="json")
        self.add(self.a, category="top")
        self.assertEqual(self.a.delete("/api/me/").status_code, 204)
        self.assertEqual(ClothingItem.objects.count(), 0)


class UnitTests(TestCase):
    def test_color_compat(self):
        self.assertGreater(compatibility("white", "blue"), compatibility("red", "green"))
        self.assertGreater(outfit_color_score(["white", "blue", "white"]), outfit_color_score(["red", "green", "orange"]))

    def test_ssrf_guard(self):
        for bad in ["http://example.com/a.png", "https://127.0.0.1/a.png", "https://localhost/a.png", "file:///etc/passwd"]:
            with self.assertRaises(analyzer.UnsafeURL):
                analyzer._assert_public_url(bad)

    def test_pattern_detection(self):
        self.assertEqual(analyzer.detect_pattern(Image.new("RGB", (96, 96), (200, 30, 30))), "solid")
        stripes = Image.new("RGB", (96, 96), "white")
        for x in range(0, 96, 8):
            for y in range(96):
                for dx in range(4):
                    stripes.putpixel((x + dx, y), (0, 0, 120))
        self.assertEqual(analyzer.detect_pattern(stripes), "striped")
